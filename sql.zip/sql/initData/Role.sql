﻿/****** Object:  Table [dbo].[Role]    Script Date: 2/23/2016 2:37:14 AM ******/

DROP TABLE [dbo].[MeetingRoom]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Role](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[ApprovedDays] [int] NULL,
	[CreatedTime] [datetime2](7) NULL,
	[Abbreviation] [nvarchar](50) NULL,
	[IsInitRole] [int] NULL,
	[CreateUser] [nvarchar](255) NULL,
	[Status] [int] NULL,
 CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- ----------------------------
-- Records of Role
-- ----------------------------
SET IDENTITY_INSERT [dbo].[Role] ON
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'1', N'总经理', N'1', N'2015-12-05 00:00:00.0000000', N'CEO', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'2', N'副总经理', N'1', N'2015-12-05 00:00:00.0000000', N'CFO', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'3', N'总监', N'1', N'2015-12-05 00:00:00.0000000', N'CTO', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'4', N'项目经理', N'1', N'2015-12-05 00:00:00.0000000', N'PM', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'5', N'工程师', N'1', N'2015-12-05 00:00:00.0000000', N'ENG', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'6', N'行政专员', N'1', N'2015-12-05 00:00:00.0000000', N'PD', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'7', N'COO/CFO', N'1', N'2015-12-05 00:00:00.0000000', N'COO/CFO', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'8', N'CEO', N'1', N'2015-12-05 00:00:00.0000000', N'CEO', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'9', N'资产管理员', N'1', N'2015-12-05 00:00:00.0000000', N'ADMIN', N'1', null, N'1')
GO
GO
SET IDENTITY_INSERT [dbo].[Role] OFF
GO

