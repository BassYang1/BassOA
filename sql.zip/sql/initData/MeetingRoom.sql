/*
Navicat SQL Server Data Transfer

Source Server         : OA
Source Server Version : 105000
Source Host           : VM-SERVER5\PLATFORM:1433
Source Database       : MissionskyOA
Source Schema         : dbo

Target Server Type    : SQL Server
Target Server Version : 105000
File Encoding         : 65001

Date: 2016-02-03 10:31:43
*/


-- ----------------------------
-- Table structure for MeetingRoom
-- ----------------------------
DROP TABLE [dbo].[MeetingRoom]
GO
CREATE TABLE [dbo].[MeetingRoom] (
[Id] int NOT NULL IDENTITY(1,1) ,
[MeetingRoomName] nvarchar(50) NULL ,
[Capacity] int NOT NULL DEFAULT ((0)) ,
[Equipment] nvarchar(200) NULL ,
[Remark] nvarchar(200) NULL ,
[Status] int NULL ,
[CreateUserName] nvarchar(255) NULL ,
[CreateDate] datetime NULL 
)


GO
DBCC CHECKIDENT(N'[dbo].[MeetingRoom]', RESEED, 4)
GO

-- ----------------------------
-- Records of MeetingRoom
-- ----------------------------
SET IDENTITY_INSERT [dbo].[MeetingRoom] ON
GO
INSERT INTO [dbo].[MeetingRoom] ([Id], [MeetingRoomName], [Capacity], [Equipment], [Remark], [Status], [CreateUserName], [CreateDate]) VALUES (N'1', N'会议室一', N'11', N'AppTV,耳麦，录音笔，无线键盘，鼠标，笔', N'', N'0', null, null)
GO
GO
INSERT INTO [dbo].[MeetingRoom] ([Id], [MeetingRoomName], [Capacity], [Equipment], [Remark], [Status], [CreateUserName], [CreateDate]) VALUES (N'2', N'会议室二', N'10', N'AppTV,白板,笔,插座', N'', N'1', null, null)
GO
GO
INSERT INTO [dbo].[MeetingRoom] ([Id], [MeetingRoomName], [Capacity], [Equipment], [Remark], [Status], [CreateUserName], [CreateDate]) VALUES (N'3', N'会议室三', N'15', N'白板,笔,台式电脑', N'', N'1', null, null)
GO
GO
INSERT INTO [dbo].[MeetingRoom] ([Id], [MeetingRoomName], [Capacity], [Equipment], [Remark], [Status], [CreateUserName], [CreateDate]) VALUES (N'4', N'test', N'10', N'test', N'test123', N'1', N'Kevin Zhao', N'2016-01-27 17:25:23.120')
GO
GO
SET IDENTITY_INSERT [dbo].[MeetingRoom] OFF
GO

-- ----------------------------
-- Indexes structure for table MeetingRoom
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table MeetingRoom
-- ----------------------------
ALTER TABLE [dbo].[MeetingRoom] ADD PRIMARY KEY ([Id])
GO
