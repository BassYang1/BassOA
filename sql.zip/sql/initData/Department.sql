/*
Navicat SQL Server Data Transfer

Source Server         : OA
Source Server Version : 105000
Source Host           : VM-SERVER5\PLATFORM:1433
Source Database       : MissionskyOA
Source Schema         : dbo

Target Server Type    : SQL Server
Target Server Version : 105000
File Encoding         : 65001

Date: 2016-02-03 10:49:44
*/


-- ----------------------------
-- Table structure for Department
-- ----------------------------
DROP TABLE [dbo].[Department]
GO
CREATE TABLE [dbo].[Department] (
[Id] int NOT NULL IDENTITY(1,1) ,
[No] nvarchar(30) NOT NULL ,
[Name] nvarchar(30) NOT NULL ,
[CreatedDate] datetime NULL DEFAULT (getdate()) ,
[CreateUserName] nvarchar(30) NULL ,
[DepartmentHead] int NULL ,
[Status] int NULL 
)


GO
DBCC CHECKIDENT(N'[dbo].[Department]', RESEED, 4)
GO

-- ----------------------------
-- Records of Department
-- ----------------------------
SET IDENTITY_INSERT [dbo].[Department] ON
GO
INSERT INTO [dbo].[Department] ([Id], [No], [Name], [CreatedDate], [CreateUserName], [DepartmentHead], [Status]) VALUES (N'1', N'MSSKYC', N'国内', N'2015-12-29 14:45:39.723', null, null, N'0')
GO
GO
INSERT INTO [dbo].[Department] ([Id], [No], [Name], [CreatedDate], [CreateUserName], [DepartmentHead], [Status]) VALUES (N'2', N'MSSKYA', N'国外', N'2015-12-29 14:45:39.723', null, null, N'0')
GO
GO
SET IDENTITY_INSERT [dbo].[Department] OFF
GO

-- ----------------------------
-- Indexes structure for table Department
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table Department
-- ----------------------------
ALTER TABLE [dbo].[Department] ADD PRIMARY KEY ([Id])
GO
