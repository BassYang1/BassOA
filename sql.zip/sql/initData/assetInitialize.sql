INSERT INTO [dbo].[User]
           ([No]
           ,[ChineseName]
           ,[EnglishName]
           ,[QQID]
           ,[Email]
           ,[Phone]
           ,[Password]
           ,[Gender]
           ,[DirectlySupervisorId]
           ,[DeptId]
           ,[ProjectId]
           ,[Position]
           ,[Token]
           ,[Status]
           ,[Available]
           ,[TodayStatus]
           ,[JoinDate]
           ,[ExpirationTime]
           ,[CreatedTime])
     VALUES
           (NULL
           ,'�ʲ�����Ա'
           ,'Assets Manager'
           ,NULL
           ,'assets.manager@missionsky.com'
           ,NULL
           ,NULL
           ,1
           ,0
           ,1
           ,0
           ,'�ʲ�����Ա'
           ,NULL
           ,0
           ,1
           ,1
           ,GETDATE()
           ,NULL
           ,GETDATE())

SET IDENTITY_INSERT [dbo].[AssetAttribute] ON 
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (1, N'���', NULL, 0, 1)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (2, N'����', NULL, 2, 2)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (3, N'���(RMB)', NULL, 1, 3)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (4, N'���(HKD)', NULL, 1, 4)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (5, N'��ϸ����', NULL, 2, 5)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (6, N'�ɹ�����', NULL, 3, 6)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (7, N'�ɹ���', NULL, 2, 7)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (8, N'��������', NULL, 2, 8)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (9, N'�۾�', NULL, 2, 9)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (10, N'ʹ����', NULL, 2, 10)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (11, N'��ŵص�', NULL, 2, 11)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (12, N'��ע', NULL, 2, 12)
SET IDENTITY_INSERT [dbo].[AssetAttribute] OFF

SET IDENTITY_INSERT [dbo].[AssetType] ON 
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (1, N'����', 1)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (2, N'��ʾ��', 2)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (3, N'MACMINI����', 3)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (4, N'�ʼǱ�����', 4)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (5, N'ƽ�����', 5)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (6, N'�ֻ�', 6)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (7, N'���ݴ�', 7)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (8, N'�����̶��ʲ�', 8)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (9, N'�����׺�Ʒ', 9)
SET IDENTITY_INSERT [dbo].[AssetType] OFF

INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 1, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 2, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 3, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 4, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 5, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 6, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 7, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 8, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 9, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]