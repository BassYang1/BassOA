﻿USE MissionskyOA
GO

IF EXISTS(SELECT 1 FROM SYSOBJECTS WHERE ID = OBJECT_ID(N'SummaryTodayStatus') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE SummaryTodayStatus
GO

CREATE PROCEDURE SummaryTodayStatus
AS
BEGIN
	DECLARE @today DATETIME = GETDATE() --今天日期

	SELECT O.UserId, ISNULL(O.OrderType, 0), StartDate, EndDate, @today, 
			CAST(StartDate AS NVARCHAR) + ' ' + CAST(StartTime AS NVARCHAR), CAST(EndDate AS NVARCHAR) + ' ' + CAST(EndTime AS NVARCHAR)
		FROM [Order] O INNER JOIN OrderDet D ON O.Id = D.OrderId	
		WHERE DATEDIFF(N, CAST(StartDate AS NVARCHAR) + ' ' + CAST(StartTime AS NVARCHAR), @today) >= 0 
			AND DATEDIFF(N, CAST(EndDate AS NVARCHAR) + ' ' + CAST(EndTime AS NVARCHAR), @today) <= 0 --今天请假
			AND ISNULL(O.OrderType, 0) IN (1, 2, 3, 5, 6, 7, 8) --年假，病假，调休，婚假，产假，丧假，事假

END
GO

EXEC SummaryTodayStatus;
GO


SELECT * FROM BookBorrow;
SELECT * FROM Book;

SELECT UserId FROM BookBorrow
WHERE ISNULL([Status], 0) = 1 --借阅中
AND DATEDIFF(DAY, ReturnDate, GETDATE()) >= 0 --已到预计归还日期


UPDATE AuditMessage SET Message = N'更新员工当前状态' WHERE [Type] = 201;
SELECT * FROM [User] WHERE TodayStatus = 3;

/*
DELETE FROM AuditMessage  WHERE [Type] IN (201, 202);
DELETE FROM NotificationTargetUser WHERE NotificationId IN (SELECT Id FROM Notification WHerE MessageContent LIKE '%请及时归还您借阅的图书%');
DELETE FROM Notification WHerE MessageContent LIKE '%请及时归还您借阅的图书%';
*/

SELECT * FROM AuditMessage  WHERE [Type] IN (201, 202);
SELECT * FROM Notification WHerE MessageContent LIKE '%请及时归还您借阅的图书%';

SELECT * FROM AuditMessage WHERE [Type] = 201 AND CONVERT(VARCHAR(10), ISNULL(CreatedTime, GETDATE()), 111) = CONVERT(VARCHAR(10), GETDATE(), 111)

SELECT CAST(GETDATE() AS NVARCHAR(10));

SELECT CONVERT(VARCHAR(10), ISNULL(CreatedTime, GETDATE()), 111);