--UPDATE [User] SET Token = CAST(Id AS NVARCHAR(5)) + CAST(Id AS NVARCHAR(5)) + 'rnGfU1IUAd8u4/c+qy5QAE/fAPpbyl2NUen+v8wxlQB5sYUTEZtrt4jbntnalRybXwdv2w', ExpirationTime = DATEADD(dd, 10, GETDATE()) WHERE Id IN (45, 41, 1, 101, 6, 27, 28, 31, 88, 87, 94, 88, 84, 89);
SELECT Id, Email, EnglishName, ChineseName, Token, ExpirationTime, DeptId FROM [User] WHERE Id IN (45, 41, 1, 101, 6, 27, 28, 31, 88, 87, 94, 88, 84, 89);

SELECT * FROM ExpenseMain WHERE Id = 1086 AND ApplyUserId = 116;
SELECT * FROM ExpenseDetail WHERE MId = 1086;
SELECT * FROM ExpenseMember WHERE DId = 1155;
SELECT * FROM ExpenseAuditHistory WHERE ExpenseId = 1086;