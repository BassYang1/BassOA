--UPDATE [User] SET Token = CAST(Id AS NVARCHAR(5)) + CAST(Id AS NVARCHAR(5)) + 'rnGfU1IUAd8u4/c+qy5QAE/fAPpbyl2NUen+v8wxlQB5sYUTEZtrt4jbntnalRybXwdv2w', ExpirationTime = DATEADD(dd, 10, GETDATE()) WHERE Id IN (45, 41, 1, 101, 6, 27, 28, 31, 88, 87, 94, 88, 84, 89);
SELECT Id, Email, EnglishName, ChineseName, Token, ExpirationTime, DeptId FROM [User] WHERE Id IN (45, 41, 1, 101, 6, 27, 28, 31, 88, 87, 94, 88, 84, 89);


SELECT TOP 3 * FROM [Order] A INNER JOIN [OrderDet] B ON A.Id = B.OrderId 
WHERE A.UserId IN (28) 
AND A.OrderNo > 1397
ORDER BY A.CreatedTime DESC;

SELECT TOP 3 * FROM [Order] A INNER JOIN [WorkflowProcess] B ON A.OrderNo = B.OrderNo 
WHERE A.UserId IN (28) 
AND A.OrderNo > 1397
ORDER BY B.CreatedTime DESC;

SELECT * FROM [WorkflowProcess] WHERE OrderNo IN (2754);