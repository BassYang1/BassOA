﻿

--加班请假申请(个人)
--UPDATE [User] SET Token = CAST(Id AS NVARCHAR(5)) + CAST(Id AS NVARCHAR(5)) + 'rnGfU1IUAd8u4/c+qy5QAE/fAPpbyl2NUen+v8wxlQB5sYUTEZtrt4jbntnalRybXwdv2w', ExpirationTime = DATEADD(dd, 10, GETDATE()) WHERE Id IN (45, 41, 1, 101, 6, 27, 28, 31, 88, 87, 94, 88, 84, 89);
SELECT Id, Email, EnglishName, ChineseName, Token, ExpirationTime, DeptId FROM [User] WHERE Id IN (45, 41, 1, 101, 6, 27, 28, 31, 88, 87, 94, 88, 84, 89);


SELECT TOP 3 * FROM [Order] A INNER JOIN [OrderDet] B ON A.Id = B.OrderId 
WHERE A.UserId IN (65) AND A.OrderNo = 2691
ORDER BY A.CreatedTime DESC;

SELECT TOP 3 * FROM [Order] A INNER JOIN [WorkflowProcess] B ON A.OrderNo = B.OrderNo 
WHERE A.UserId IN (65) AND A.OrderNo = 2691
ORDER BY B.CreatedTime DESC;

/*

DELETE FROM WorkflowProcess WHERE OrderNo = 2685;
DELETE FROM OrderDet WHERE OrderId IN (SELECT Id FROM [Order] WHERE OrderNo = 2685);
DELETE FROM [Order] WHERE OrderNo = 2685;

*/

SELECT * FROM [USER] WHERE Id=41 AND [user].deptid=2



--加班请假申请
SELECT * FROM [Order] WHERE NextAudit = 125;

--报销申请
/*
	DELETE FROM ExpenseMember;
	DELETE FROM ExpenseDetail;
	DELETE FROM ExpenseAuditHistory;
	DELETE FROM ExpenseMain;
*/

SELECT Id, Email, EnglishName, ChineseName, Token, ExpirationTime FROM [User] WHERE Id IN (41, 1, 101, 6, 27, 28, 31, 88, 87, 94, 88, 84, 89);

SELECT TOP 5 * FROM ExpenseMain WHERE Id > 2142 ORDER BY Id DESC;
SELECT TOP 5 * FROM ExpenseMember ORDER BY Id DESC;
SELECT TOP 5 * FROM ExpenseDetail ORDER BY Id DESC;
SELECT TOP 5 * FROM ExpenseAuditHistory WHERE ExpenseId > 2142 ORDER BY Id DESC;


SELEcT * FROM ExpenseMain E INNER JOIN ExpenseAuditHistory EAH ON E.Id = EAH.ExpenseId WHERE E.Id = 1097;


--日志
SELECT TOP 20 * FROM [Log] ORDER BY Date DESC;

--
SELECT * FROM [User] WHERE ID = 27;