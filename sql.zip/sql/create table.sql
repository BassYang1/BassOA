﻿USE MissionskyOA;

/*
DROP TABLE AuditMessage;
CREATE TABLE AuditMessage(
	Id INT IDENTITY(1, 1) PRIMARY KEY,
	UserId INT NOT NULL,
	[Type] INT NOT NULL,
	[Message] NVARCHAR(100) NOT NULL,
	[Status] INT DEFAULT(0), --默认值 0-未读
	CreatedTime DateTime DEFAULT(GETDATE())
)


DROP TABLE AttendanceSummary;
CREATE TABLE AttendanceSummary(
	Id INT IDENTITY(1, 1) PRIMARY KEY,
	UserId INT NOT NULL,
	[Type] INT NOT NULL,
	SummaryYear INT NOT NULL,
	SummaryValue FLOAT DEFAULT(0) NOT NULL
)

ALTER TABLE [User] ADD AnnualLeave FLOAT DEFAULT(0) NOT NULL;
*/

--2015-12-18
/*
DROP TABLE WorkflowProcess;
CREATE TABLE WorkflowProcess(
	Id INT IDENTITY(1, 1) PRIMARY KEY,
	OrderId INT NOT NULL,
	FlowId INT NOT NULL,
	StepId INT NOT NULL,
	Operator INT NOT NULL,
	Operation INT NOT NULL,
	OperationDesc NVARCHAR(100),
	CreatedTime DATETIME DEFAULT(GETDATE()) NOT NULL
);

DROP TABLE WorkflowStep;
CREATE TABLE WorkflowStep(
	Id INT IDENTITY(1, 1) PRIMARY KEY,
	FlowId INT NOT NULL,
	Name VARCHAR(30) NOT NUll,
	Operator INT NOT NULL,
	OperatorType INT NOT NULL, 
	MinTimes FLOAT DEFAULT(0) NOT NULL,
	MaxTimes FLOAT NOT NULL,
	[Type] INT,
	NextStep INT,
	[Desc] NVARCHAR(100),
	CreatedTime DATETIME DEFAULT(GETDATE()) NOT NULL
);

DROP TABLE Workflow;
CREATE TABLE Workflow(
	Id INT IDENTITY(1, 1) PRIMARY KEY,
	Name VARCHAR(30) NOT NUll,
	[Desc] NVARCHAR(100),
	[Type] INT NOT NULL,
	[Status] BIT NOT NULL,
	CreatedTime DATETIME DEFAULT(GETDATE()) NOT NULL
);

ALTER TABLE [dbo].[WorkflowStep]  WITH CHECK ADD  CONSTRAINT [FK_WorkflowStep_Workflow] FOREIGN KEY([FlowId])
REFERENCES [dbo].[Workflow] ([Id])
GO

ALTER TABLE [dbo].[WorkflowStep] CHECK CONSTRAINT [FK_WorkflowStep_Workflow]
GO

ALTER TABLE [dbo].[WorkflowProcess]  WITH CHECK ADD  CONSTRAINT [FK_WorkflowProcess_WorkflowStep] FOREIGN KEY([StepId])
REFERENCES [dbo].[WorkflowStep] ([Id])
GO

ALTER TABLE [dbo].[WorkflowProcess] CHECK CONSTRAINT [FK_WorkflowProcess_WorkflowStep]
GO

ALTER TABLE [dbo].[WorkflowProcess]  WITH CHECK ADD  CONSTRAINT [FK_WorkflowProcess_User] FOREIGN KEY([Operator])
REFERENCES [dbo].[User] ([Id])
GO

ALTER TABLE [dbo].[WorkflowProcess] CHECK CONSTRAINT [FK_WorkflowProcess_WorkflowStep]
GO

ALTER TABLE [Order] ADD WorkflowId INT NOT NULL;

ALTER TABLE [Order] ADD NextStep INT;

ALTER TABLE [Order] ADD NextAudit INT;

ALTER TABLE Workflow ADD [Type] INT DEFAULT(0) NOT NULL;

AlTER TABLE WorkflowProcess ADD OrderId INT DEFAULT(0) NOT NULL;


AlTER TABLE WorkflowStep Add Operator INT DEFAULT(0) NOT NULL;
AlTER TABLE WorkflowStep Add OperatorType INT DEFAULT(0) NOT NULL;
AlTER TABLE WorkflowStep Add [Type] INT;

--DAYS <= 1
--DAYS > 1 AND DAYS <= 3
*/

--2015-12-25
/*
ALTER TABLE [User] DROP COLUMN AnnualLeave;
ALTER TABLE [User] ADD Available BIT DEFAULT(1) NOT NULL;
ALTER TABLE [User] ADD TodayStatus INT DEFAULT(1) NOT NULL;
ALTER TABLE [User] ADD [No] NVARCHAR(30);


SELECT * FROM [User];
SELECT * FROM AttendanceSummary;

DROP TABLE AttendanceSummary;
CREATE TABLE AttendanceSummary(
	Id INT IDENTITY(1, 1) PRIMARY KEY,
	UserId INT NOT NULL,
	[Type] INT NOT NULL,
	SummaryYear INT NOT NULL,
	LastValue FLOAT,
	ThisValue FLOAT,
	RestValue FLOAT,
)
*/

--2015-12-29
/*
DROP TABLE Department;
CREATE TABLE Department(
	Id INT IDENTITY(1, 1) PRIMARY KEY,
	[No] NVARCHAR(30) NOT NULL,
	Name NVARCHAR(30) NOT NULL,
	CreatedDate Datetime DEFAULT(GETDATE())
)

INSERT INTO Department([No], Name) VALUES('MSSKY', 'MSSKY');

ALTER TABLE [User] ADD JoinDate DATE;
ALTER TABLE [User] ADD DeptId INT;
ALTER TABLE [User] ADD Position NVARCHAR(30);

UPDATE [User] SET DeptId = 1, JoinDate = GETDATE();

DROP TABLE AttendanceSummary;
CREATE TABLE AttendanceSummary(
	Id INT IDENTITY(1, 1) PRIMARY KEY,
	UserId INT NOT NULL,
	[Type] INT NOT NULL,
	[Year] INT NOT NULL,
	LastValue FLOAT,
	BaseValue FLOAT,
	RemainValue FLOAT,
)
*/

--2016-01-05
/*
--图书
DROP TABLE Book;
CREATE TABLE Book(
	Id INT IDENTITY(1, 1) PRIMARY KEY,
	Name NVARCHAR(50) NOT NULL, --书名
	ISBN NVARCHAR(30) NOT NULL, --编码
	[Type] NVARCHAR(30), --类型
	[Desc] NTEXT, --简介
	Author NVARCHAR(30), --作者
	[Source] INT, --来源: 捐赠，采购
	Donor INT, --捐赠用户
	[Status] INT, --状态: 在库，借出
	Reader INT, --当前借阅用户
	CreatedDate DATETIME DEFAULT(GETDATE()) NOT NULL --入库日期
);

--图书借阅
DROP TABLE BookBorrow;
CREATE TABLE BookBorrow(
	Id INT IDENTITY(1, 1) PRIMARY KEY,
	UserId INT NOT NULL, --借阅用户
	BookId INT NOT NULL, --图书ID
	[Status] INT, --状态: 已归还，借阅，续借，丢失
	BorrowDate DATETIME NOT NULL, --借阅日期
	ReturnDate DATETIME NOT NULL --预计归还日期
);

--图书评论
DROP TABLE BookComment;
CREATE TABLE BookComment(
	Id INT IDENTITY(1, 1) PRIMARY KEY,
	UserId INT NOT NULL, --评论用户
	BookId INT NOT NULL, --图书
	Comment NTEXT, --评论详细
	Rating INT, --评分
	CreatedDate DATETIME DEFAULT(GETDATE()) NOT NULL --评论日期
);

--附件表
DROP TABLE Attachment;
CREATE TABLE Attachment(
	Id INT IDENTITY(1,1) PRIMARY KEY,
	EntityType NVARCHAR(30) NOT NULL, --类型: 图书封面
	EntityId INT NOT NULL, --ID: 图书ID
	[Name] NVARCHAR(50), --附件名
	[Desc] NVARCHAR(100), --描述
	Content VARBINARY(MAX) NULL, --附件
	CreatedTime DATETIME DEFAULT(GETDATE()) NOT NULL --创建日期
);

--数据字典
DROP TABLE DataDict;
CREATE TABLE DataDict(
	Id INT IDENTITY(1,1) PRIMARY KEY,
	[Type] NVARCHAR(30) NOT NULL, --类型: 图书分类, 设备分类
	[Value] NVARCHAR(30) NOT NULL,
	[Text] NVARCHAR(30),
	Parent NVARCHAR(20)
);

INSERT INTO Book(Name, ISBN, [Desc])
VALUES(N'Google软件测试之道', 'ISB-MS20131112052', N'Google软件测试之道是一本好书。');

INSERT INTO Book(Name, ISBN, [Desc], [Source], Donor)
VALUES(N'智慧的云计算', 'ISB-MS20131112051', N'智慧的云计算', 2, 2);

INSERT INTO BookBorrow(UserId, BookId, Status, BorrowDate, ReturnDate)
VALUES(27, 1, 3, DATEADD(DAY, -20, GETDATE()), DATEADD(day, -2, GETDATE())),
(27, 1, 1, DATEADD(DAY, -2, GETDATE()), DATEADD(day, 7, GETDATE())),
(27, 2, 3, DATEADD(DAY, -30, GETDATE()), DATEADD(day, -17, GETDATE())),
(28, 1, 3, DATEADD(DAY, -7, GETDATE()), DATEADD(day, -3, GETDATE())),
(28, 2, 1, DATEADD(DAY, -10, GETDATE()), DATEADD(day, 10, GETDATE()))

*/
--2016-01-08
/*
ALTER TABLE Workflow ADD Condition NTEXT;
ALTER TABLE Workflow ADD ConditionDesc NVARCHAR(100);
*/


--2016-01-11
/*
DROP TABLE Attachment;
CREATE TABLE Attachment(
	Id INT IDENTITY(1,1) PRIMARY KEY,
	EntityType NVARCHAR(30) NOT NULL, --类型: 图书封面
	EntityId INT NOT NULL, --ID: 图书ID
	[Name] NVARCHAR(50), --附件名
	[Desc] NVARCHAR(100), --描述
	Content VARBINARY(MAX) NULL, --附件
	CreatedTime DATETIME DEFAULT(GETDATE()) NOT NULL --创建日期
);

ALTER TABLE Book ADD BarCode NVARCHAR(100);
*/
--2016-01-19
/*
DROP TABLE ScheduledTaskHistory;
GO
CREATE TABLE ScheduledTaskHistory(
	Id INT IDENTITY(1,1) PRIMARY KEY,
	TaskId Int NOT NULL,	
	Result BIT NOT NULL, --成功，失败
	[Desc] NTEXT, --执行结果
	CreatedTime DATETIME DEFAULT(GETDATE()) NOT NULL --执行时间
);
GO

DROP TABLE ScheduledTask;
GO
CREATE TABLE ScheduledTask(
	Id INT IDENTITY(1,1) PRIMARY KEY,
	[Name] NVARCHAR(50), --定时任务名称
	Interval INT NOT NULL, --执行间隔
	Unit INT NOT NULL, --执行间隔单，秒，分，时，天
	Status INT NOT NULL, --开始，暂停,
	TaskClass NVARCHAR(100) NOT NULL, --任务处理类
	[Desc] NVARCHAR(100), --定时任务说明
	LastExecTime DATETIME, --上次执行时间
	CreatedTime DATETIME DEFAULT(GETDATE()) NOT NULL --创建定时任务日期
);
GO

ALTER TABLE ScheduledTaskHistory  WITH CHECK ADD  CONSTRAINT [FK_ScheduledTask_History] FOREIGN KEY(TaskId)
REFERENCES ScheduledTask (Id)
GO

ALTER TABLE ScheduledTaskHistory CHECK CONSTRAINT [FK_ScheduledTask_History]
GO

INSERT INTO ScheduledTask([Name], Interval, Unit, Status, [Desc], TaskClass)
VALUES(N'更新员工当前状态', 10, 2, 2, N'统计员工是否在公司上班，还是请假外出', 'MissionskyOA.Services.Task.SummaryTodayStatus'),
(N'通知用户归还图书', 1, 4, 2, N'如果用户到期图书未归还，则每日提醒一次', 'MissionskyOA.Services.Task.NotifyReturnBook')

INSERT INTO ScheduledTask([Name], Interval, Unit, Status, [Desc], TaskClass)
VALUES(N'通知会议开始结束', 30, 1, 1, N'提前5分钟提示用户会议开始或结束', 'MissionskyOA.Services.Task.NotifyMeeting')
*/


--2016-01-25
/*
CREATE TABLE Report(	
	Id INT IDENTITY(1,1) PRIMARY KEY,
	Name NVARCHAR(100) NOT NULL UNIQUE,
	[Desc] NVARCHAR(100), --报表说明
	CreatedTime DATETIME DEFAULT(GETDATE()) NOT NULL --创建日期
)

CREATE TABLE ReportConfig(	
	Id INT IDENTITY(1,1) PRIMARY KEY,
	ReportId INT NOT NULL, --报表Id
	Config NVARCHAR(100) NOT NULL,
	Value NVARCHAR(100) NOT NULL,
	CreatedTime DATETIME DEFAULT(GETDATE()) NOT NULL --创建日期
)

ALTER TABLE ReportConfig  WITH CHECK ADD  CONSTRAINT [FK_Report_Config] FOREIGN KEY(ReportId)
REFERENCES Report (Id)
GO

ALTER TABLE ReportConfig CHECK CONSTRAINT [FK_Report_Config]
GO

INSERT INTO Report(Name, [Desc])
VALUES(N'统计员工个信请假加班记录', N'统计员工个信请假加班记录');

INSERT INTO ReportConfig(ReportId, Config, Value)
VALUES(1, 'ServiceUrl', 'https://bass-yang.missionsky.com/MSSQLReportService'),
(1, 'ReportPath', '/MissionskyOA_SummaryReportByPerson'),
(1, 'DefaultFormat', 'PDF'),
(1, 'UserName', 'bass.yang'),
(1, 'Password', 'bass1'),
(1, 'Domain', 'MSSKY')

INSERT INTO DataDict(Type, Value, Text)
VALUES(N'报表格式', 'PDF', 'PDF'),
(N'报表格式', 'Word', 'Word'),
(N'报表格式', 'Excel', 'Excel')
*/


--2016-01-26
/*
CREATE TABLE ReportParameter(	
	Id INT IDENTITY(1,1) PRIMARY KEY,
	ReportId INT NOT NULL, --报表Id
	Name NVARCHAR(30) NOT NULL,
	Type NVARCHAR(20) NOT NULL,
	Nullable BIT,
	CreatedTime DATETIME DEFAULT(GETDATE()) NOT NULL --创建日期
)

ALTER TABLE ReportParameter  WITH CHECK ADD  CONSTRAINT [FK_Report_Parameter] FOREIGN KEY(ReportId)
REFERENCES Report (Id)
GO

ALTER TABLE ReportParameter CHECK CONSTRAINT [FK_Report_Parameter]
GO

INSERT INTO ReportParameter(ReportId, Name, Type)
VALUES(1, 'StartDate', 'Date'),
(1, 'EndDate', 'Date')

INSERT INTO DataDict(Type, Value, Text)
VALUES(N'报表参数类型', 'Integer', 'Integer'),
(N'报表参数类型', 'Float', 'Float'),
(N'报表参数类型', 'Boolean', 'Boolean'),
(N'报表参数类型', 'DateTime', 'DateTime'),
(N'报表参数类型', 'Date', 'Date'),
(N'报表参数类型', 'String', 'String')

--2016-02-23
ALTER TABLE ReportParameter ADD Desc NVARCHAR(50);

INSERT INTO DataDict(Type, Value, Text)
VALUES(N'报表参数类型', 'DropdownList', 'DropdownList');

--2016-02-26
ALTER TABLE [OrderDet] ADD Audit NVARCHAR(50);
*/


--3.0
/*
--2016-03-03
--[Order]添加申请单号
ALTER TABLE [Order] ADD OrderNo INT; --申请单号
GO
UPDATE [Order] SET OrderNo = Id; --更新申请单号

ALTER TABLE [Order] ALTER COLUMN OrderNo INT NOT NULL;
GO

--[WorkflowProcess]申请单Id更改为申请单号
ALTER TABLE [WorkflowProcess] ADD OrderNo INT; //申请单号
GO

UPDATE [WorkflowProcess] SET OrderNo = OrderId;
GO

ALTER TABLE [WorkflowProcess] ALTER COLUMN OrderNo INT NOT NULL;
GO

ALTER TABLE [WorkflowProcess] DROP COLUMN OrderId; 
GO

--2016-03-28
INSERT INTO DataDict(Type, Value, Text)
VALUES(N'2016法定假日', '20160101', N'元旦节'),
	(N'2016法定假日', '20160102', N'元旦节'),
	(N'2016法定假日', '20160103', N'元旦节'),
	(N'2016法定假日', '20160207', N'除夕'),
	(N'2016法定假日', '20160208', N'春节'),
	(N'2016法定假日', '20160209', N'春节'),
	(N'2016法定假日', '20160210', N'春节'),
	(N'2016法定假日', '20160211', N'春节'),
	(N'2016法定假日', '20160212', N'春节'),
	(N'2016法定假日', '20160213', N'春节'),
	(N'2016法定假日', '20160402', N'清明节'),
	(N'2016法定假日', '20160403', N'清明节'),
	(N'2016法定假日', '20160404', N'清明节'),
	(N'2016法定假日', '20160430', N'劳动节'),
	(N'2016法定假日', '20160501', N'劳动节'),
	(N'2016法定假日', '20160502', N'劳动节'),
	(N'2016法定假日', '20160609', N'端午节'),
	(N'2016法定假日', '20160610', N'端午节'),
	(N'2016法定假日', '20160611', N'端午节'),
	(N'2016法定假日', '20160915', N'中秋节'),
	(N'2016法定假日', '20160916', N'中秋节'),
	(N'2016法定假日', '20160917', N'中秋节'),
	(N'2016法定假日', '20161001', N'国庆节'),
	(N'2016法定假日', '20161002', N'国庆节'),
	(N'2016法定假日', '20161003', N'国庆节'),
	(N'2016法定假日', '20161004', N'国庆节'),
	(N'2016法定假日', '20161005', N'国庆节'),
	(N'2016法定假日', '20161006', N'国庆节'),
	(N'2016法定假日', '20161007', N'国庆节')

	
INSERT INTO DataDict(Type, Value, Text)
VALUES(N'2016周末补班', '20160206', N'春节补班'),
	(N'2016周末补班', '20160214', N'春节补班'),
	(N'2016周末补班', '20160612', N'端午节补班'),
	(N'2016周末补班', '20160918', N'中秋节补班'),
	(N'2016周末补班', '20161008', N'国庆节补班'),
	(N'2016周末补班', '20161009', N'国庆节补班')
	

--2016-04-07
DROP TABLE AttendanceSummaryDetail
CREATE TABLE AttendanceSummaryDetail(
	UserId INT NULL,
	SumDate Date NULL,
	WorkHours FLOAT NULL, --当日工作时长
	OrderHours FLOAT NULL, --当时申请(请假或加班)时间
	FixedHC BIT DEFAULT(0)
)
	
*/


--3.1
/*
--2016-04-12
ALTER TABLE Report ADD IsOpen BIT NOT NULL DEFAULT(1);
ALTER TABLE Report ADD No NVARCHAR(20) NOT NULL DEFAULT('');

ALTER TABLE ExpenseMain ADD PrintForm INT DEFAULT(0);
ALTER TABLE ExpenseMain ADD ConfirmForm BIT DEFAULT(0);
*/

SELECT * FROM Report;
SELECT * FROM ReportConfig;

SELECT * FROM DataDict WHERE Type IN ('2016法定假日', '2016周末补班')

SELECT * FROM DataDict;

SELECT * FROM Book;
SELECT * FROM BookBorrow;
SELECT * FROM BookComment;

SELECT * FROM [USER] WHERE Id=2 AND deptid=1;

SELECT * FROM ScheduledTask;
SELECT * FROM ScheduledTaskHistory;
SELECT * FROM Notification ORDER BY CreatedTime DESC;

/*
DELETE FROM [WorkflowProcess];
DELETE FROM [OrderDet];
DELETE FROM [Order];
*/

SELECT TOP 5 * FROM [Order] ORDER BY CreatedTime DESC;
SELECT TOP 5 * FROM [OrderDet] ORDER BY OrderId DESC;
SELECT TOP 5 * FROM [WorkflowProcess] ORDER BY CreatedTime DESC;
SELECT * FROM [AttendanceSummary] WHERE UserId IN (1, 2 ,3) AND [Type] IN (4);


SELECT ISNULL(MAX(BatchApplyId), 0) + 1 FROM [Order];

SELECT * FROM [Order] WHERE UserId = 1 OR ApplyUserId = 1;




                        SELECT * FROM [Order]
                        WHERE ISNULL(Status, 0) != 4 --过滤已取消的单
                                AND ApplyUserId !=1
                                AND OrderNo IN (
	                                SELECT DISTINCT OrderNo FROM WorkflowProcess WHERE Operator = 1 AND ISNULL(StepId, 0) != 0 --已审批
	                                UNION
	                                SELECT DISTINCT OrderNo AS OrderId FROM [Order] WHERE ISNULL(NextAudit, 0) = 1 AND ISNULL(NextStep, 0) != 0 --待审批
                                );
                    