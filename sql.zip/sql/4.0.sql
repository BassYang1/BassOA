﻿
USE MissionskyOA_DEV;
GO

IF NOT EXISTS(SElECT 1 FROM dbo.SYSOBJECTS WHERE Id = OBJECT_ID(N'WorkTask') AND XType = N'U')
BEGIN
	CREATE TABLE WorkTask(		
		Id INT IDENTITY(1, 1) PRIMARY KEY,
		Outline NVARCHAR(50) NOT NULL, --任务内容
		Type INT NOT NULL,
		Status INT NOT NULL,
		[Desc] NVARCHAR(150), --任务详细说明
		MeetingId INT,
		ProjectId INT,
		Sponsor INT NOT NULL, --发起人
		Supervisor INT, --监督人
		Executor INT, --执行人
		[Source] INT NOT NULL, --任务来源
		Priority INT NOT NULL, --优先级 
		Workload INT NOT NULL, --工作量(小时)
		StartTime DATETIME,
		EndTime DATETIME,	--任务截止时间
		CompleteTime DATETIME, --完成时间
		CloseTime DATETIME,
		CreatedTime DATETIME NOT NULL DEFAULT(GETDATE())
	);
END;
GO

IF NOT EXISTS(SELECT 1 FROM dbo.SYSOBJECTS WHERE Id = OBJECT_ID(N'WorkTaskHistory') AND XType = N'U')
BEGIN
	CREATE TABLE WorkTaskHistory(
		Id INT IDENTITY(1, 1) PRIMARY KEY,
		TaskId INT NOT NULL FOREIGN KEY REFERENCES WorkTask(Id),
		Operator INT NOT NULL, --操作人
		Status INT NOT NULL,  --操作状态
		Audit NVARCHAR(100), --操作说明
		CreatedTime DATETIME NOT NULL DEFAULT(GETDATE())
	);
END;
GO

IF NOT EXISTS(SELECT 1 FROM dbo.SYSOBJECTS WHERE Id = OBJECT_ID(N'WorkTaskComment') AND XType = N'U')
BEGIN
	CREATE TABLE WorkTaskComment(
		Id INT IDENTITY(1, 1) PRIMARY KEY,
		TaskId INT NOT NULL FOREIGN KEY REFERENCES WorkTask(Id),
		UserId INT NOT NULL, --评论人
		Comment NVARCHAR(150) NOT NULL, --评论
		CreatedTime DATETIME NOT NULL DEFAULT(GETDATE())
	);
END;
GO


IF NOT EXISTS(SELECT 1 FROM dbo.SYSCOLUMNS WHERE Id = OBJECT_ID(N'User') AND Name = N'AuthNotify')
BEGIN
	ALTER TABLE [User] ADD AuthNotify NVARCHAR(500);
END
GO

UPDATE [User] SET AuthNotify = N'LeaveApprove:1;OvertimeApprove:1;ExpenseApprove:1;Notice:1;WorkTask:1;' WHERE LEN(ISNULL(AuthNotify, N'')) <= 0;
GO


IF NOT EXISTS(SELECT 1 FROM dbo.SYSCOLUMNS WHERE Id = OBJECT_ID(N'WorkTask') AND Name = N'Urgency')
BEGIN
	ALTER TABLE [WorkTask] ADD Urgency INT; --紧急性: 高中低
END
GO

IF NOT EXISTS(SELECT 1 FROM dbo.SYSCOLUMNS WHERE Id = OBJECT_ID(N'WorkTask') AND Name = N'Importance')
BEGIN
	ALTER TABLE [WorkTask] ADD Importance INT; --重要性: 高中低
END
GO

IF NOT EXISTS(SELECT 1 FROM dbo.SYSCOLUMNS WHERE Id = OBJECT_ID(N'OrderDet') AND Name = N'InformLeader')
BEGIN
	ALTER TABLE OrderDet ADD InformLeader BIT; --是否告知领导
END
GO

IF NOT EXISTS(SELECT 1 FROM dbo.SYSCOLUMNS WHERE Id = OBJECT_ID(N'OrderDet') AND Name = N'WorkTransfer ')
BEGIN
	ALTER TABLE OrderDet ADD WorkTransfer BIT; --是否工作交接
END
GO

IF NOT EXISTS(SELECT 1 FROM dbo.SYSCOLUMNS WHERE Id = OBJECT_ID(N'OrderDet') AND Name = N'Recipient ')
BEGIN
	ALTER TABLE OrderDet ADD Recipient INT; --移交人
END
GO

IF NOT EXISTS(SELECT 1 FROM dbo.SYSCOLUMNS WHERE Id = OBJECT_ID(N'WorkTaskHistory') AND Name = N'OperatorName')
	ALTER TABLE WorkTaskHistory ADD OperatorName NVARCHAR(30); --操作人姓名
GO

IF EXISTS(SELECT 1 FROM dbo.SYSCOLUMNS WHERE Id = OBJECT_ID(N'WorkTaskHistory') AND Name = N'OperatorName')
	UPDATE W SET W.OperatorName = U.EnglishName FROM WorkTaskHistory W, [User] U WHERE U.Id = ISNULL(W.Operator, 0)
GO
