﻿--加班请假申请(个人)
--UPDATE [User] SET Token = CAST(Id AS NVARCHAR(5)) + CAST(Id AS NVARCHAR(5)) + 'rnGfU1IUAd8u4/c+qy5QAE/fAPpbyl2NUen+v8wxlQB5sYUTEZtrt4jbntnalRybXwdv2w', ExpirationTime = DATEADD(dd, 10, GETDATE()) WHERE Id IN (45, 41, 1, 101, 6, 27, 28, 31, 88, 87, 94, 88, 84, 89);
SELECT Id, Email, EnglishName, ChineseName, Token, ExpirationTime, DeptId FROM [User] WHERE Id IN (45, 41, 1, 101, 6, 27, 28, 31, 88, 87, 94, 88, 84, 89);

SELECT TOP 5 * FROM WorkTask ORDER BY CreatedTime DESC;
SELECT TOP 5 * FROM WorkTaskHistory ORDER BY CreatedTime DESC;
SELECT TOP 5 * FROM WorkTaskComment ORDER BY CreatedTime DESC;

SELECT * FROM [User] WHERE Id = 28;