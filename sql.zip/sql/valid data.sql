﻿--1, 重复提交
;WITH TOrder AS(
	SELECT O.Id, O.Status, O.UserId, O.RefOrderId, D.OrderId, D.StartDate, D.StartTime, D.EndDate, D.EndTime, D.[Description], D.IOHours 
	FROM [Order] O INNER JOIN [OrderDet] D ON D.OrderId = O.Id
	WHERE ISNULL(O.Status, 0) IN (0, 1, 2)
)

SELECT * FROM TOrder
WHERE Id IN (
		SELECT OrderId FROM TOrder D
		WHERE EXISTS (
				SELECT 1 FROM TOrder WHERE OrderId != D.OrderId AND UserId = D.UserId AND StartDate = D.StartDate 
				AND StartTime = D.StartTime AND EndDate = D.EndDate AND EndDate = D.EndDate 
				AND [Description] = D.[Description] AND IOHours = D.IOHours)
)


--2, 更新假期数据不一致
--原因1: 拒绝加班时逻辑错误，加班时间算做调休，调休假增多
IF EXISTS(SELECT 1 FROM tempdb..SYSOBJECTS WHERE Id = OBJECT_ID('tempdb..##TOrder'))
	DROP TABLE ##TOrder

SELECT Id, UserId, Status, (CASE WHEN OrderType = 3 THEN 4 ELSE OrderType END) AS OrderType, NextStep, NextAudit INTO ##TOrder FROM [Order]

;WITH TSum AS(
	SELECT O.UserId, O.OrderType, SUM(D.IOHours) AS Used
	FROM ##TOrder O INNER JOIN [OrderDet] D ON D.OrderId = O.Id
	WHERE O.Status IN (2, 5) AND ISNULL(NextStep, 0) = 0 AND ISNULL(NextAudit, 0) = 0
	GROUP BY O.UserId, O.OrderType 
)

SELECT A.UserId, U.EnglishName, U.ChineseName, A.Type, A.LastValue, S.Used, A.RemainValue
FROM AttendanceSummary A 
	INNER JOIN TSum S ON A.UserId = S.UserId AND A.Type = S.OrderType AND (A.LastValue + S.Used + (CASE WHEN A.Type = 1 THEN A.BaseValue ELSE 0 END)) != A.RemainValue
	INNER JOIN [User] U ON A.UserId = U.Id;
		
IF EXISTS(SELECT 1 FROM tempdb..SYSOBJECTS WHERE Id = OBJECT_ID('tempdb..##TOrder'))
	DROP TABLE ##TOrder


--查看数据
SELECT SUM(IOHours) FROM [Order] A INNER JOIN [OrderDet] B ON A.Id = B.OrderId 
WHERE A.UserId = 65 AND A.OrderType = 3 AND ISNULL(NextStep, 0) = 0 AND ISNULL(NextAudit, 0) = 0 AND STATUS IN (2, 5);

SELECT * FROM [Order] A INNER JOIN [OrderDet] B ON A.Id = B.OrderId 
WHERE A.UserId = 65 AND A.OrderType = 3 
ORDER BY A.CreatedTime DESC;

--UPDATE AttendanceSummary SET RemainValue = 6.5 WHERE UserId = 65 AND Type = 4
SELECT * FROM AttendanceSummary WHERE UserId = 65;



--3, 查询是否有正在处理申请单
SELECT ISNULL(SUM(D.IOHours), 0) AS UncompletedValue FROM [Order] O INNER JOIN OrderDet D ON O.Id = D.OrderId 
WHERE O.UserId = 2  --用户
AND ISNULL(O.OrderType, 0) = 1 --假期类型
AND ISNULL(O.RefOrderId, 0) = 0 --正常申请
AND (ISNULL(O.NextStep, 0) != 0 AND NOT EXISTS(SELECT 1 FROM WorkflowStep WHERE [Type] = 3 AND ID = O.NextStep)) --流程未完成且当前步骤不是财务审批(未扣除的假期申请)
AND YEAR(D.StartDate) = YEAR(GETDATE()) AND YEAR(D.EndDate) = YEAR(GETDATE()) --本年度的休假


SELECT * FROM [Order] O INNER JOIN OrderDet D ON O.Id = D.OrderId 
WHERE O.UserId = 2  --用户
AND ISNULL(O.OrderType, 0) = 1 --假期类型
AND ISNULL(O.RefOrderId, 0) = 0 --正常申请
AND (ISNULL(O.NextStep, 0) != 0 AND NOT EXISTS(SELECT 1 FROM WorkflowStep WHERE [Type] = 3 AND ID = O.NextStep)) --流程未完成且当前步骤不是财务审批(未扣除的假期申请)
AND YEAR(D.StartDate) = YEAR(GETDATE()) AND YEAR(D.EndDate) = YEAR(GETDATE()) --本年度的休假