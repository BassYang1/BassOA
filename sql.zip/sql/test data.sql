﻿
SELECT TOP 3 * FROM [Order] A INNER JOIN [OrderDet] B ON A.Id = B.OrderId 
WHERE A.UserId = 87
ORDER BY A.CreatedTime DESC;

SELECT TOP 3 * FROM [Order] A INNER JOIN [WorkflowProcess] B ON A.OrderNo = B.OrderNo 
WHERE A.UserId = 87 ORDER BY B.CreatedTime DESC;

--UPDATE AttendanceSummary SET RemainValue = 200 WHERE UserId = 2 AND Type IN (1, 4)
SELECT * FROM AttendanceSummary WHERE UserId = 2;

SELECT TOP 10 * FROM [dbo].[Notification] ORDER BY CreatedTime DESC;
SELECT * FROM [User] WHERE EnglishName IN ('Bass Yang', '')
SELECT TOP 1 * FROM WorkflowProcess ORDER BY CreatedTime DESC;


SELECT TOP 1 * FROM [dbo].[Notification] ORDER BY CreatedTime DESC


--DELETE FROM WorkflowProcess WHERE ORDERID = 80;

SELECT * FROM WorkflowProcess WHERE ORDERID = 80;


SELECT * FROM [Order] WHERE RefOrderId = 214;

--图书接口测试
UPDATE [User] SET ExpirationTime = DATEADD(D, 10, GETDATE()) WHERE Id = 2;

SELECT U.Id AS UserId, U.ChineseName, U.EnglishName, U.Email, U.[Password], U.Token, B.Id AS BookId, B.Name, B1.BorrowDate, B1.ReturnDate, U.ExpirationTime FROM [User] U
INNER JOIN BookBorrow B1 ON U.Id = B1.UserId
INNER JOIN Book B ON B.Id = B1.BookId
WHERE B1.[Status] = 1 --Borrowing

SELECT U.Id AS UserId, U.ChineseName, U.EnglishName, U.Email, U.[Password], U.Token, B.Id AS BookId, B.Name, B1.BorrowDate, B1.ReturnDate, U.ExpirationTime FROM [User] U
INNER JOIN BookBorrow B1 ON B1.UserId = U.Id
INNER JOIN Book B ON B.Id = B1.BookId
WHERE U.Id = 2;

SELECT * FROM Attachment WHERE EntityId = 2;

SELECT * FROM ScheduledTask;






--UPDATE [User] SET Token = CAST(Id AS NVARCHAR(5)) + CAST(Id AS NVARCHAR(5)) + 'rnGfU1IUAd8u4/c+qy5QAE/fAPpbyl2NUen+v8wxlQB5sYUTEZtrt4jbntnalRybXwdv2w', ExpirationTime = DATEADD(dd, 10, GETDATE()) WHERE Id IN (27, 28, 88, 87, 94, 88, 84);
SELECT Id, Email, EnglishName, ChineseName, Token, ExpirationTime FROM [User] WHERE Id IN (27, 28, 88, 87, 94, 88, 84);


SELECT TOP 3 * FROM [Order] A INNER JOIN [OrderDet] B ON A.Id = B.OrderId 
WHERE A.UserId = 28 
ORDER BY A.CreatedTime DESC;

SELECT TOP 3 * FROM [Order] A INNER JOIN [WorkflowProcess] B ON A.OrderNo = B.OrderNo 
WHERE A.UserId = 28 ORDER BY B.CreatedTime DESC;