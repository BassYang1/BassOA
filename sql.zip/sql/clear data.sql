﻿SELECT TOP 1 * FROM [Order] ORDER BY CreatedTime DESC;
SELECT TOP 1 * FROM [OrderDet] ORDER BY Id DESC;
SELECT * FROM AttendanceSummary WHERE UserId = 2;
SELECT TOP 1 * FROM [dbo].[Notification] ORDER BY CreatedTime DESC;
SELECT * FROM [User] WHERE EnglishName IN ('Bass Yang', '')
SELECT TOP 1 * FROM WorkflowProcess ORDER BY CreatedTime DESC;


SELECT TOP 1 * FROM [dbo].[Notification] ORDER BY CreatedTime DESC


DELETE FROM WorkflowProcess WHERE ORDERID = 80;

SELECT * FROM WorkflowProcess WHERE ORDERID = 80;

SELECT * FROM AttendanceSummary;

truncate table WorkflowProcess;
truncate table OrderDet;
delete from [Order];
DBCC CHECKIDENT ([Order],reseed,0);
truncate table AcceptProxy;
truncate table [log];
update AttendanceSummary set BaseValue =0 where [type] not in (1); --只有年假有基准值
update AttendanceSummary set LastValue =0 where [type] not in (1, 4); --只有年假、加班有上一年剩余值
update AttendanceSummary set RemainValue =0 where [type] not in (1, 4); --只有年假、加班有剩余值
update AttendanceSummary set RemainValue = LastValue + BaseValue where [type] in (1, 4); --只有年假、加班有剩余值


delete from workflowprocess where OrderId in (select id from [Order] where workflowid = 0 or workflowid is null);
delete from OrderDet where OrderId in (select id from [Order] where workflowid = 0 or workflowid is null);
delete from [Order] where workflowid = 0 or workflowid is null;

select * from [user]where [user].id= 2;





