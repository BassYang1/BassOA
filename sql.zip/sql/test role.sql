﻿
SELECT R.Name, U.* FROM [User] U INNER JOIN [UserRole] UR ON U.Id = UR.UserId INNER JOIN [Role] R ON UR.RoleId = R.Id WHERE R.Name LIKE '%总监%';
SELECT R.Name, U.* FROM [User] U INNER JOIN [UserRole] UR ON U.Id = UR.UserId INNER JOIN [Role] R ON UR.RoleId = R.Id WHERE EnglishName LIKE '%Eddy%';
SELECT * FROM [User] WHERE Id in (84, 85, 129)
SELECT * FROM [Workflow] --WHERE Id in (3, 2, 1);
SELECT * FROM [Order] WHERE NextAudit = 99;

SELECT * FROM UserRole WHERE UserId = 99;
SELECT * FROM [Role];

SELECT * FROM WorkFlowStep WHERE Operator = 3;


UPDATE [ORDER] SET WorkflowId = 6 WHERE Id = 4906;