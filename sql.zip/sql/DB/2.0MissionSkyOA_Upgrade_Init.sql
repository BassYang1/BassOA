--资产管理
INSERT INTO [dbo].[User]
           ([No]
           ,[ChineseName]
           ,[EnglishName]
           ,[QQID]
           ,[Email]
           ,[Phone]
           ,[Password]
           ,[Gender]
           ,[DirectlySupervisorId]
           ,[DeptId]
           ,[ProjectId]
           ,[Position]
           ,[Token]
           ,[Status]
           ,[Available]
           ,[TodayStatus]
           ,[JoinDate]
           ,[ExpirationTime]
           ,[CreatedTime])
     VALUES
           (NULL
           ,N'资产管理员'
           ,'Assets Manager'
           ,NULL
           ,'assets.manager@missionsky.com'
           ,NULL
           ,NULL
           ,1
           ,0
           ,1
           ,0
           ,N'资产管理员'
           ,NULL
           ,0
           ,1
           ,1
           ,GETDATE()
           ,NULL
           ,GETDATE())

SET IDENTITY_INSERT [dbo].[AssetAttribute] ON 
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (1, N'编号', NULL, 0, 1)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (2, N'名称', NULL, 2, 2)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (3, N'金额(RMB)', NULL, 1, 3)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (4, N'金额(HKD)', NULL, 1, 4)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (5, N'详细配置', NULL, 2, 5)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (6, N'采购日期', NULL, 3, 6)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (7, N'采购人', NULL, 2, 7)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (8, N'入账区域', NULL, 2, 8)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (9, N'折旧', NULL, 2, 9)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (10, N'使用人', NULL, 2, 10)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (11, N'存放地点', NULL, 2, 11)
INSERT [dbo].[AssetAttribute] ([Id], [Name], [Description], [DataType], [Sort]) VALUES (12, N'备注', NULL, 2, 12)
SET IDENTITY_INSERT [dbo].[AssetAttribute] OFF

SET IDENTITY_INSERT [dbo].[AssetType] ON 
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (1, N'主机', 1)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (2, N'显示器', 2)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (3, N'MACMINI电脑', 3)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (4, N'笔记本电脑', 4)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (5, N'平板电脑', 5)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (6, N'手机', 6)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (7, N'午休床', 7)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (8, N'其他固定资产', 8)
INSERT [dbo].[AssetType] ([Id], [Name], [Sort]) VALUES (9, N'其他易耗品', 9)
SET IDENTITY_INSERT [dbo].[AssetType] OFF

INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 1, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 2, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 3, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 4, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 5, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 6, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 7, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 8, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]
INSERT INTO [dbo].[AssetTypeAttribute](TypeId, AttributeId) select 9, [dbo].[AssetAttribute].Id from [dbo].[AssetAttribute]


--部门
/*
Navicat SQL Server Data Transfer

Source Server         : OA
Source Server Version : 105000
Source Host           : VM-SERVER5\PLATFORM:1433
Source Database       : MissionskyOA
Source Schema         : dbo

Target Server Type    : SQL Server
Target Server Version : 105000
File Encoding         : 65001

Date: 2016-02-03 10:49:44
*/


-- ----------------------------
-- Table structure for Department
-- ----------------------------
DROP TABLE [dbo].[Department]
GO
CREATE TABLE [dbo].[Department] (
[Id] int NOT NULL IDENTITY(1,1) ,
[No] nvarchar(30) NOT NULL ,
[Name] nvarchar(30) NOT NULL ,
[CreatedDate] datetime NULL DEFAULT (getdate()) ,
[CreateUserName] nvarchar(30) NULL ,
[DepartmentHead] int NULL ,
[Status] int NULL 
)


GO
DBCC CHECKIDENT(N'[dbo].[Department]', RESEED, 4)
GO

-- ----------------------------
-- Records of Department
-- ----------------------------
SET IDENTITY_INSERT [dbo].[Department] ON
GO
INSERT INTO [dbo].[Department] ([Id], [No], [Name], [CreatedDate], [CreateUserName], [DepartmentHead], [Status]) VALUES (N'1', N'MSSKYC', N'国内', N'2015-12-29 14:45:39.723', null, null, N'0')
GO
GO
INSERT INTO [dbo].[Department] ([Id], [No], [Name], [CreatedDate], [CreateUserName], [DepartmentHead], [Status]) VALUES (N'2', N'MSSKYA', N'国外', N'2015-12-29 14:45:39.723', null, null, N'0')
GO
GO
SET IDENTITY_INSERT [dbo].[Department] OFF
GO

-- ----------------------------
-- Indexes structure for table Department
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table Department
-- ----------------------------
ALTER TABLE [dbo].[Department] ADD PRIMARY KEY ([Id])
GO



--会议
/*
Navicat SQL Server Data Transfer

Source Server         : OA
Source Server Version : 105000
Source Host           : VM-SERVER5\PLATFORM:1433
Source Database       : MissionskyOA
Source Schema         : dbo

Target Server Type    : SQL Server
Target Server Version : 105000
File Encoding         : 65001

Date: 2016-02-03 10:31:43
*/


-- ----------------------------
-- Table structure for MeetingRoom
-- ----------------------------
DROP TABLE [dbo].[MeetingRoom]
GO
CREATE TABLE [dbo].[MeetingRoom] (
[Id] int NOT NULL IDENTITY(1,1) ,
[MeetingRoomName] nvarchar(50) NULL ,
[Capacity] int NOT NULL DEFAULT ((0)) ,
[Equipment] nvarchar(200) NULL ,
[Remark] nvarchar(200) NULL ,
[Status] int NULL ,
[CreateUserName] nvarchar(255) NULL ,
[CreateDate] datetime NULL 
)


GO
DBCC CHECKIDENT(N'[dbo].[MeetingRoom]', RESEED, 4)
GO

-- ----------------------------
-- Records of MeetingRoom
-- ----------------------------
SET IDENTITY_INSERT [dbo].[MeetingRoom] ON
GO
INSERT INTO [dbo].[MeetingRoom] ([Id], [MeetingRoomName], [Capacity], [Equipment], [Remark], [Status], [CreateUserName], [CreateDate]) VALUES (N'1', N'会议室一', N'11', N'AppTV,耳麦，录音笔，无线键盘，鼠标，笔', N'', N'0', null, null)
GO
GO
INSERT INTO [dbo].[MeetingRoom] ([Id], [MeetingRoomName], [Capacity], [Equipment], [Remark], [Status], [CreateUserName], [CreateDate]) VALUES (N'2', N'会议室二', N'10', N'AppTV,白板,笔,插座', N'', N'1', null, null)
GO
GO
INSERT INTO [dbo].[MeetingRoom] ([Id], [MeetingRoomName], [Capacity], [Equipment], [Remark], [Status], [CreateUserName], [CreateDate]) VALUES (N'3', N'会议室三', N'15', N'白板,笔,台式电脑', N'', N'1', null, null)
GO
GO
INSERT INTO [dbo].[MeetingRoom] ([Id], [MeetingRoomName], [Capacity], [Equipment], [Remark], [Status], [CreateUserName], [CreateDate]) VALUES (N'4', N'test', N'10', N'test', N'test123', N'1', N'Kevin Zhao', N'2016-01-27 17:25:23.120')
GO
GO
SET IDENTITY_INSERT [dbo].[MeetingRoom] OFF
GO

-- ----------------------------
-- Indexes structure for table MeetingRoom
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table MeetingRoom
-- ----------------------------
ALTER TABLE [dbo].[MeetingRoom] ADD PRIMARY KEY ([Id])
GO

--角色
/****** Object:  Table [dbo].[Role]    Script Date: 2/23/2016 2:37:14 AM ******/

DROP TABLE [dbo].[MeetingRoom]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Role](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[ApprovedDays] [int] NULL,
	[CreatedTime] [datetime2](7) NULL,
	[Abbreviation] [nvarchar](50) NULL,
	[IsInitRole] [int] NULL,
	[CreateUser] [nvarchar](255) NULL,
	[Status] [int] NULL,
 CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- ----------------------------
-- Records of Role
-- ----------------------------
SET IDENTITY_INSERT [dbo].[Role] ON
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'1', N'总经理', N'1', N'2015-12-05 00:00:00.0000000', N'CEO', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'2', N'副总经理', N'1', N'2015-12-05 00:00:00.0000000', N'CFO', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'3', N'总监', N'1', N'2015-12-05 00:00:00.0000000', N'CTO', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'4', N'项目经理', N'1', N'2015-12-05 00:00:00.0000000', N'PM', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'5', N'工程师', N'1', N'2015-12-05 00:00:00.0000000', N'ENG', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'6', N'行政专员', N'1', N'2015-12-05 00:00:00.0000000', N'PD', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'7', N'COO/CFO', N'1', N'2015-12-05 00:00:00.0000000', N'COO/CFO', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'8', N'CEO', N'1', N'2015-12-05 00:00:00.0000000', N'CEO', N'1', null, N'1')
GO
GO
INSERT INTO [dbo].[Role] ([Id], [Name], [ApprovedDays], [CreatedTime], [Abbreviation], [IsInitRole], [CreateUser], [Status]) VALUES (N'9', N'资产管理员', N'1', N'2015-12-05 00:00:00.0000000', N'ADMIN', N'1', null, N'1')
GO
GO
SET IDENTITY_INSERT [dbo].[Role] OFF
GO


--定时任务
INSERT INTO ScheduledTask([Name], Interval, Unit, Status, [Desc], TaskClass)
VALUES(N'更新员工当前状态', 10, 2, 2, N'统计员工是否在公司上班，还是请假外出', 'MissionskyOA.Services.Task.SummaryTodayStatus'),
(N'通知用户归还图书', 1, 4, 2, N'如果用户到期图书未归还，则每日提醒一次', 'MissionskyOA.Services.Task.NotifyReturnBook')

INSERT INTO ScheduledTask([Name], Interval, Unit, Status, [Desc], TaskClass)
VALUES(N'通知会议开始结束', 30, 1, 1, N'提前5分钟提示用户会议开始或结束', 'MissionskyOA.Services.Task.NotifyMeeting')

--字典数据
INSERT INTO DataDict(Type, Value, Text)
VALUES(N'报表格式', 'PDF', 'PDF'),
(N'报表格式', 'Word', 'Word'),
(N'报表格式', 'Excel', 'Excel')

INSERT INTO DataDict(Type, Value, Text)
VALUES(N'报表参数类型', 'Integer', 'Integer'),
(N'报表参数类型', 'Float', 'Float'),
(N'报表参数类型', 'Boolean', 'Boolean'),
(N'报表参数类型', 'DateTime', 'DateTime'),
(N'报表参数类型', 'Date', 'Date'),
(N'报表参数类型', 'String', 'String'),
(N'报表参数类型', 'DropdownList', 'DropdownList')

--报表参数表
CREATE TABLE ReportParameter(	
	Id INT IDENTITY(1,1) PRIMARY KEY,
	ReportId INT NOT NULL, --报表Id
	Name NVARCHAR(30) NOT NULL,
	[Desc] NVARCHAR(50) NOT NULL,
	Type NVARCHAR(20) NOT NULL,
	Nullable BIT,
	[DataSource] NVARCHAR(30) NULL,
	CreatedTime DATETIME DEFAULT(GETDATE()) NOT NULL --创建日期
)


ALTER TABLE [OrderDet] ADD Audit NVARCHAR(50); --订单审批结果




