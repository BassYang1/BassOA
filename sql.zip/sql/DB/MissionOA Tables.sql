
--User Role UserRole Avatar Department
CREATE TABLE [dbo].[User](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[No] [nvarchar](30) NULL,
	[ChineseName] [nvarchar](50) NULL,
	[EnglishName] [nvarchar](50) NULL,
	[QQID] [nvarchar](50) NULL,
	[Email] [nvarchar](50) NULL ,
	[Phone] [nvarchar](50) NULL,
	[Password] [nvarchar](255) NULL,
	[Gender] [int] NULL,
	[DirectlySupervisorId] [int] NULL,
	[DeptId] [int] NULL,
	[ProjectId] [int] NULL,
	[Position] [nvarchar](30) NULL,
	[Token] [nvarchar](255) NULL,
	[Status] [int] NULL,
	[Available] [bit] NOT NULL,
	[TodayStatus] [int] NOT NULL,
	[JoinDate] [date] NULL,
	[ExpirationTime] [datetime2](7) NULL,
	[CreatedTime] [datetime2](7) NULL,
 CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[User] ADD  DEFAULT ((1)) FOR [Available]
GO

ALTER TABLE [dbo].[User] ADD  DEFAULT ((1)) FOR [TodayStatus]
GO

CREATE TABLE [dbo].[Role](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[ApprovedDays] [int] NULL,
	[CreatedTime] [datetime2](7) NULL,
 CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

CREATE TABLE [dbo].[Avatar](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[FileName] [nvarchar](1000) NULL,
	[Content] [varbinary](max) NULL,
	[CreatedTime] [datetime2](7) NULL,
 CONSTRAINT [PK_Avatar] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Avatar]  WITH CHECK ADD  CONSTRAINT [FK_Avatar_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([Id])
GO

ALTER TABLE [dbo].[Avatar] CHECK CONSTRAINT [FK_Avatar_User]
GO


CREATE TABLE [dbo].[UserRole](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[RoleId] [int] NOT NULL,
 CONSTRAINT [PK_UserRole] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[UserRole]  WITH CHECK ADD  CONSTRAINT [FK_UserRole_Role] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Role] ([Id])
GO

ALTER TABLE [dbo].[UserRole] CHECK CONSTRAINT [FK_UserRole_Role]
GO

ALTER TABLE [dbo].[UserRole]  WITH CHECK ADD  CONSTRAINT [FK_UserRole_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([Id])
GO

ALTER TABLE [dbo].[UserRole] CHECK CONSTRAINT [FK_UserRole_User]
GO

CREATE TABLE [dbo].[Department](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[No] [nvarchar](30) NOT NULL,
	[Name] [nvarchar](30) NOT NULL,
	[CreatedDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Department] ADD  DEFAULT (getdate()) FOR [CreatedDate]
GO
--Order OrderDet
CREATE TABLE [dbo].[Order](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Status] [int] NULL,
	[OrderType] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[ApplyUserId] [int] NULL,
	[RefOrderId] [int] NULL,
	[WorkflowId] [int] NULL,
	[NextStep] [int] NULL,
	[NextAudit] [int] NULL,
	[CreatedTime] [datetime2](7) NULL,
 CONSTRAINT [PK_Order] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Order]  WITH CHECK ADD  CONSTRAINT [FK_Order_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([Id])
GO

ALTER TABLE [dbo].[Order] CHECK CONSTRAINT [FK_Order_User]
GO

CREATE TABLE [dbo].[OrderDet](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[OrderId] [int] NOT NULL,
	[StartDate] [date] NOT NULL,
	[StartTime] [time](7) NULL,
	[EndDate] [date] NOT NULL,
	[EndTime] [time](7) NULL,
	[IOHours] [float] NULL,
	[Description] [nvarchar](max) NULL,
	[FileName] [nvarchar](max) NULL,
	[FileContent] [varbinary](max) NULL,
 CONSTRAINT [PK_OrderDet] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[OrderDet]  WITH CHECK ADD  CONSTRAINT [FK_OrderDet_Order] FOREIGN KEY([OrderId])
REFERENCES [dbo].[Order] ([Id])
GO

ALTER TABLE [dbo].[OrderDet] CHECK CONSTRAINT [FK_OrderDet_Order]
GO
--Project AcceptProxy
CREATE TABLE [dbo].[Project](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NULL,
	[CreatedTime] [datetime2](7) NULL,
 CONSTRAINT [PK_Project] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

CREATE TABLE [dbo].[AcceptProxy](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Date] [date] NOT NULL,
	[Description] [nvarchar](200) NULL,
	[FileName] [nvarchar](1000) NULL,
	[Content] [varbinary](max) NULL,
	[AcceptUserId] [int] NOT NULL,
	[Status] [int] NOT NULL,
	[Courier] [nvarchar](200) NULL,
	[LeaveMessage] [nvarchar](200) NULL,
	[CourierPhone] [nvarchar](50) NULL,
	[CreateUserId] [int] NULL,
	[LastModifyUserId] [int] NULL,
	[LastModifyTime] [datetime2](7) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

--Log AttendanceSummary AuditMessage
CREATE TABLE [dbo].[Log](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Date] [datetime] NULL,
	[Thread] [nvarchar](255) NULL,
	[Level] [nvarchar](50) NULL,
	[Logger] [nvarchar](255) NULL,
	[Message] [nvarchar](4000) NULL,
	[Exception] [nvarchar](2000) NULL,
 CONSTRAINT [PK_Log] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

CREATE TABLE [dbo].[AttendanceSummary](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[Type] [int] NOT NULL,
	[Year] [int] NOT NULL,
	[LastValue] [float] NULL,
	[BaseValue] [float] NULL,
	[RemainValue] [float] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

CREATE TABLE [dbo].[AuditMessage](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Type] [int] NOT NULL,
	[Message] [nvarchar](100) NOT NULL,
	[UserId] [int] NOT NULL,
	[Status] [int] NULL DEFAULT ((0)),
	[CreatedTime] [datetime] NULL DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

--Notification NotificationTargetUser
CREATE TABLE [dbo].[Notification](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[BusinessType] [int] NULL,
	[MessageContent] [nvarchar](max) NULL,
	[Target] [nvarchar](255) NULL,
	[MessageType] [int] NOT NULL,
	[Scope] [int] NOT NULL,
	[MessagePrams] [nvarchar](max) NULL,
	[CreatedUserId] [int] NULL,
	[CreatedTime] [datetime] NOT NULL,
 CONSTRAINT [PK_dbo.NotificationList] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

CREATE TABLE [dbo].[NotificationTargetUser](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[NotificationId] [int] NOT NULL,
	[TargetUserId] [int] NOT NULL,
 CONSTRAINT [PK_NotificationTargetUser] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[NotificationTargetUser]  WITH CHECK ADD  CONSTRAINT [FK_NotificationTargetUser_Notification] FOREIGN KEY([NotificationId])
REFERENCES [dbo].[Notification] ([Id])
GO

ALTER TABLE [dbo].[NotificationTargetUser] CHECK CONSTRAINT [FK_NotificationTargetUser_Notification]
GO

--MeetingRoom MeetingCalendar
CREATE TABLE [dbo].[MeetingRoom](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[MeetingRoomName] [nvarchar](50) NULL,
	[Capacity] [int] NOT NULL,
	[Equipment] [nvarchar](200) NULL,
	[Remark] [nvarchar](200) NULL,
	[Status] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[MeetingRoom] ADD  DEFAULT ((0)) FOR [Capacity]
GO


CREATE TABLE [dbo].[MeetingCalendar](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[MeetingRoomId] [int] NOT NULL,
	[Title] [nvarchar](200) NULL,
	[StartDate] [date] NOT NULL,
	[StartTime] [time](7) NULL,
	[EndDate] [date] NOT NULL,
	[EndTime] [time](7) NULL,
	[Host] [nvarchar](200) NULL,
	[Participants] [nvarchar](200) NULL,
	[OptionalParticipants] [nvarchar](200) NULL,
	[MeetingContext] [nvarchar](200) NULL,
	[MeetingSummary] [nvarchar](200) NULL,
	[Status] [int] NOT NULL,
	[ApplyUserId] [int] NOT NULL,
	[CreatedTime] [datetime2](7) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- Workflow WorkflowStep WorkflowProcess
CREATE TABLE [dbo].[Workflow](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](30) NOT NULL,
	[Desc] [nvarchar](100) NULL,
	[Type] [int] NOT NULL,
	[Status] [bit] NOT NULL,
	[CreatedTime] [datetime] NOT NULL DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

CREATE TABLE [dbo].[WorkflowStep](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FlowId] [int] NOT NULL,
	[Name] [nvarchar](30) NOT NULL,
	[Operator] [int] NOT NULL,
	[OperatorType] [int] NOT NULL,
	[MinTimes] [float] NOT NULL DEFAULT ((0)),
	[MaxTimes] [float] NOT NULL,
	[Type] [int] NULL,
	[NextStep] [int] NULL,
	[Desc] [nvarchar](100) NULL,
	[CreatedTime] [datetime] NOT NULL DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[WorkflowStep]  WITH CHECK ADD  CONSTRAINT [FK_WorkflowStep_Workflow] FOREIGN KEY([FlowId])
REFERENCES [dbo].[Workflow] ([Id])
GO

ALTER TABLE [dbo].[WorkflowStep] CHECK CONSTRAINT [FK_WorkflowStep_Workflow]
GO

CREATE TABLE [dbo].[WorkflowProcess](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[OrderId] [int] NOT NULL,
	[FlowId] [int] NOT NULL,
	[StepId] [int] NOT NULL,
	[Operator] [int] NOT NULL,
	[Operation] [int] NOT NULL,
	[OperationDesc] [nvarchar](100) NULL,
	[CreatedTime] [datetime] NOT NULL DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[WorkflowProcess]  WITH CHECK ADD  CONSTRAINT [FK_WorkflowProcess_User] FOREIGN KEY([Operator])
REFERENCES [dbo].[User] ([Id])
GO

ALTER TABLE [dbo].[WorkflowProcess] CHECK CONSTRAINT [FK_WorkflowProcess_User]
GO