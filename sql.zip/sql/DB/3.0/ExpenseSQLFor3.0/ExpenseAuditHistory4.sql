/*
Navicat SQL Server Data Transfer

Source Server         : oa_serverf
Source Server Version : 110000
Source Host           : OA-SERVER:1433
Source Database       : MissionskyOA_DEV
Source Schema         : dbo

Target Server Type    : SQL Server
Target Server Version : 110000
File Encoding         : 65001

Date: 2016-04-08 09:45:58
*/


-- ----------------------------
-- Table structure for ExpenseAuditHistory
-- ----------------------------
DROP TABLE [dbo].[ExpenseAuditHistory]
GO
CREATE TABLE [dbo].[ExpenseAuditHistory] (
[Id] int NOT NULL IDENTITY(1,1) ,
[CurrentAudit] int NOT NULL ,
[NextAudit] int NULL ,
[ExpenseId] int NOT NULL ,
[Status] int NULL ,
[AuditMessage] nvarchar(200) NULL ,
[CreatedTime] datetime2(7) NULL 
)


GO
DBCC CHECKIDENT(N'[dbo].[ExpenseAuditHistory]', RESEED, 1094)
GO

-- ----------------------------
-- Indexes structure for table ExpenseAuditHistory
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table ExpenseAuditHistory
-- ----------------------------
ALTER TABLE [dbo].[ExpenseAuditHistory] ADD PRIMARY KEY ([Id])
GO

-- ----------------------------
-- Foreign Key structure for table [dbo].[ExpenseAuditHistory]
-- ----------------------------
ALTER TABLE [dbo].[ExpenseAuditHistory] ADD FOREIGN KEY ([ExpenseId]) REFERENCES [dbo].[ExpenseMain] ([Id]) ON DELETE NO ACTION ON UPDATE NO ACTION
GO
