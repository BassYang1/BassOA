/*
Navicat SQL Server Data Transfer

Source Server         : oa_serverf
Source Server Version : 110000
Source Host           : OA-SERVER:1433
Source Database       : MissionskyOA_DEV
Source Schema         : dbo

Target Server Type    : SQL Server
Target Server Version : 110000
File Encoding         : 65001

Date: 2016-04-08 09:46:15
*/


-- ----------------------------
-- Table structure for ExpenseDetail
-- ----------------------------
DROP TABLE [dbo].[ExpenseDetail]
GO
CREATE TABLE [dbo].[ExpenseDetail] (
[Id] int NOT NULL IDENTITY(1,1) ,
[MId] int NOT NULL ,
[ODate] datetime NOT NULL ,
[EType] int NOT NULL ,
[Remark] nvarchar(200) NULL ,
[PCount] int NOT NULL ,
[Amount] decimal(18,2) NOT NULL 
)


GO
DBCC CHECKIDENT(N'[dbo].[ExpenseDetail]', RESEED, 1131)
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseDetail', 
'COLUMN', N'MId')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'报销单编号'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseDetail'
, @level2type = 'COLUMN', @level2name = N'MId'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'报销单编号'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseDetail'
, @level2type = 'COLUMN', @level2name = N'MId'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseDetail', 
'COLUMN', N'ODate')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'发生日期'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseDetail'
, @level2type = 'COLUMN', @level2name = N'ODate'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'发生日期'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseDetail'
, @level2type = 'COLUMN', @level2name = N'ODate'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseDetail', 
'COLUMN', N'EType')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'报销类型'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseDetail'
, @level2type = 'COLUMN', @level2name = N'EType'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'报销类型'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseDetail'
, @level2type = 'COLUMN', @level2name = N'EType'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseDetail', 
'COLUMN', N'Remark')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'备注'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseDetail'
, @level2type = 'COLUMN', @level2name = N'Remark'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'备注'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseDetail'
, @level2type = 'COLUMN', @level2name = N'Remark'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseDetail', 
'COLUMN', N'PCount')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'人数'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseDetail'
, @level2type = 'COLUMN', @level2name = N'PCount'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'人数'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseDetail'
, @level2type = 'COLUMN', @level2name = N'PCount'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseDetail', 
'COLUMN', N'Amount')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'报销金额'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseDetail'
, @level2type = 'COLUMN', @level2name = N'Amount'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'报销金额'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseDetail'
, @level2type = 'COLUMN', @level2name = N'Amount'
GO

-- ----------------------------
-- Indexes structure for table ExpenseDetail
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table ExpenseDetail
-- ----------------------------
ALTER TABLE [dbo].[ExpenseDetail] ADD PRIMARY KEY ([Id])
GO

-- ----------------------------
-- Foreign Key structure for table [dbo].[ExpenseDetail]
-- ----------------------------
ALTER TABLE [dbo].[ExpenseDetail] ADD FOREIGN KEY ([MId]) REFERENCES [dbo].[ExpenseMain] ([Id]) ON DELETE NO ACTION ON UPDATE NO ACTION
GO
