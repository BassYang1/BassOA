/*
Navicat SQL Server Data Transfer

Source Server         : oa_serverf
Source Server Version : 110000
Source Host           : OA-SERVER:1433
Source Database       : MissionskyOA_DEV
Source Schema         : dbo

Target Server Type    : SQL Server
Target Server Version : 110000
File Encoding         : 65001

Date: 2016-04-08 09:46:27
*/


-- ----------------------------
-- Table structure for ExpenseMain
-- ----------------------------
DROP TABLE [dbo].[ExpenseMain]
GO
CREATE TABLE [dbo].[ExpenseMain] (
[Id] int NOT NULL IDENTITY(1,1) ,
[AuditId] int NOT NULL ,
[DeptNo] int NOT NULL ,
[ProjNo] int NOT NULL ,
[Amount] decimal(18,2) NOT NULL ,
[Reason] nvarchar(200) NULL ,
[CreatedTime] datetime2(7) NULL ,
[ApplyUserId] int NULL 
)


GO
DBCC CHECKIDENT(N'[dbo].[ExpenseMain]', RESEED, 1074)
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseMain', 
NULL, NULL)) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'报销主表'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMain'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'报销主表'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMain'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseMain', 
'COLUMN', N'AuditId')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'流程单编号'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMain'
, @level2type = 'COLUMN', @level2name = N'AuditId'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'流程单编号'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMain'
, @level2type = 'COLUMN', @level2name = N'AuditId'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseMain', 
'COLUMN', N'DeptNo')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'所属部门'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMain'
, @level2type = 'COLUMN', @level2name = N'DeptNo'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'所属部门'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMain'
, @level2type = 'COLUMN', @level2name = N'DeptNo'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseMain', 
'COLUMN', N'ProjNo')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'所在项目'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMain'
, @level2type = 'COLUMN', @level2name = N'ProjNo'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'所在项目'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMain'
, @level2type = 'COLUMN', @level2name = N'ProjNo'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseMain', 
'COLUMN', N'Amount')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'报销总金额'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMain'
, @level2type = 'COLUMN', @level2name = N'Amount'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'报销总金额'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMain'
, @level2type = 'COLUMN', @level2name = N'Amount'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseMain', 
'COLUMN', N'Reason')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'申请理由'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMain'
, @level2type = 'COLUMN', @level2name = N'Reason'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'申请理由'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMain'
, @level2type = 'COLUMN', @level2name = N'Reason'
GO

-- ----------------------------
-- Indexes structure for table ExpenseMain
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table ExpenseMain
-- ----------------------------
ALTER TABLE [dbo].[ExpenseMain] ADD PRIMARY KEY ([Id])
GO

-- ----------------------------
-- Foreign Key structure for table [dbo].[ExpenseMain]
-- ----------------------------
ALTER TABLE [dbo].[ExpenseMain] ADD FOREIGN KEY ([DeptNo]) REFERENCES [dbo].[Department] ([Id]) ON DELETE NO ACTION ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[ExpenseMain] ADD FOREIGN KEY ([ProjNo]) REFERENCES [dbo].[Project] ([Id]) ON DELETE NO ACTION ON UPDATE NO ACTION
GO
