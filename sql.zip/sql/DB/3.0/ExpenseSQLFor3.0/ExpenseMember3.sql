/*
Navicat SQL Server Data Transfer

Source Server         : oa_serverf
Source Server Version : 110000
Source Host           : OA-SERVER:1433
Source Database       : MissionskyOA_DEV
Source Schema         : dbo

Target Server Type    : SQL Server
Target Server Version : 110000
File Encoding         : 65001

Date: 2016-04-08 09:46:35
*/


-- ----------------------------
-- Table structure for ExpenseMember
-- ----------------------------
DROP TABLE [dbo].[ExpenseMember]
GO
CREATE TABLE [dbo].[ExpenseMember] (
[Id] int NOT NULL IDENTITY(1,1) ,
[DId] int NOT NULL ,
[MemberId] int NOT NULL 
)


GO
DBCC CHECKIDENT(N'[dbo].[ExpenseMember]', RESEED, 160)
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseMember', 
'COLUMN', N'DId')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'报销明细ID'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMember'
, @level2type = 'COLUMN', @level2name = N'DId'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'报销明细ID'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMember'
, @level2type = 'COLUMN', @level2name = N'DId'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'ExpenseMember', 
'COLUMN', N'MemberId')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'参与人员'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMember'
, @level2type = 'COLUMN', @level2name = N'MemberId'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'参与人员'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'ExpenseMember'
, @level2type = 'COLUMN', @level2name = N'MemberId'
GO

-- ----------------------------
-- Indexes structure for table ExpenseMember
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table ExpenseMember
-- ----------------------------
ALTER TABLE [dbo].[ExpenseMember] ADD PRIMARY KEY ([Id])
GO

-- ----------------------------
-- Foreign Key structure for table [dbo].[ExpenseMember]
-- ----------------------------
ALTER TABLE [dbo].[ExpenseMember] ADD FOREIGN KEY ([DId]) REFERENCES [dbo].[ExpenseDetail] ([Id]) ON DELETE NO ACTION ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[ExpenseMember] ADD FOREIGN KEY ([MemberId]) REFERENCES [dbo].[User] ([Id]) ON DELETE NO ACTION ON UPDATE NO ACTION
GO
