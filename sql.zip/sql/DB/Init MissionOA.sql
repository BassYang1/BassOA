﻿


INSERT INTO Role(Name, ApprovedDays) VALUES(N'总经理', 1), (N'副总经理', 1), (N'总监', 1), (N'项目经理', 1), (N'工程师', 1)

SELECT USERID, ROLEID FROM UserRole
GROUP BY USERID, ROLEID
HAVING COUNT(*) > 1

INSERT INTO UserRole(RoleId, UserId)
SELECT 4, id FROM [USER]
WHERE ENGLISHNAME IN ('Arthur Luo', 'Carly Xu', 'Felix Huang',
'Jenny Gao', 'Johnson Wang', 'Kevin Zhao', 'Peter Peng', 'Vincent Chang', 'Ting Yu')

INSERT INTO UserRole(RoleId, UserId)
SELECT 6, id FROM [USER]
WHERE ENGLISHNAME IN ('Betty Wang', 'Sylvia Huang', 'Emily Yuan')

INSERT INTO UserRole(RoleId, UserId)
SELECT 2, id FROM [USER]
WHERE ENGLISHNAME IN ('Hardy Xu')

INSERT INTO UserRole(RoleId, UserId)
SELECT 3, id FROM [USER]
WHERE ENGLISHNAME IN ('Arthur Luo')

INSERT INTO UserRole(RoleId, UserId)
SELECT 5, id FROM [USER]
WHERE ENGLISHNAME NOT IN ('Hardy Xu','Arthur Luo', 'Carly Xu', 'Felix Huang',
'Jenny Gao', 'Johnson Wang', 'Kevin Zhao', 'Peter Peng', 'Vincent Chang', 'Ting Yu','Betty Wang', 'Sylvia Huang', 'Emily Yuan')

INSERT INTO Workflow(Name, [Desc], [Type], [Status])
VALUES (N'请假流程', N'所有员工请假流程',1, 1),
(N'加班流程', N'所有员工加班流程',2, 1)

INSERT INTO WorkflowStep(FlowId, Name, Operator, OperatorType, MinTimes, MaxTimes, NextStep, [Desc], [Type])
VALUES(1, N'PM审批',	4, 1,	0,	7.5, 2, N'请假不超过7.5小时(1天)由PM审批', 1),
(1, N'VP审批', 2, 1, 7.5, 0, 3, N'请假超过7.5小时(1天)由VP审批', 1),
(1, N'行政审批', 87,	2, 7.5, 0, 4, N'行政审批', 2),
(1, N'财务审批', 89,	2, 7.5, 0, NULL, N'财务审批', 3),
(2, N'PM审批', 4, 1, 0,	7.5, 5, N'加班不超过7.5小时(1天)由PM审批', 1),
(2, N'VP审批', 2, 1, 7.5, 0, 6, N'加班超过7.5小时(1天)由VP审批', 1),
(2, N'行政审批', 87,	2, 7.5, 0, 7, N'行政审批', 2),
(2, N'财务审批', 89,	2, 7.5, 0, NULL, N'财务审批', 3)


INSERT INTO WorkflowStep(FlowId, Name, Operator, OperatorType, MinTimes, MaxTimes, NextStep, [Desc], [Type])
VALUES(1, N'PM审批',	4, 1, 0, 7.5, 2, N'请假不超过7.5小时(1天)由PM审批', 1),
(1, N'VP审批', 2, 1, 7.5, 30.0, 3, N'请假超过7.5小时(1天)由VP审批', 1),
(1, N'GM审批', 94, 2, 30.0, 0, 3, N'请假超过30.0小时(4天)由GM审批', 1),
(1, N'行政审批', 87,	2, 0, 0, 4, N'行政审批', 2),
(1, N'财务审批', 89,	2, 0, 0, NULL, N'财务审批', 3),
(2, N'PM审批', 4, 1, 0,	7.5, 5, N'加班不超过7.5小时(1天)由PM审批', 1),
(2, N'VP审批', 2, 1, 7.5, 30.0, 3, N'请假超过7.5小时(1天)由VP审批', 1),
(2, N'GM审批', 94, 2, 30.0, 0, 3, N'请假超过30.0小时(4天)由GM审批', 1),
(2, N'行政审批', 87,	2, 0, 0, 7, N'行政审批', 2),
(2, N'财务审批', 89,	2, 0, 0, NULL, N'财务审批', 3)





INSERT INTO Department([No], Name) VALUES('MSSKY', 'MSSKY');
UPDATE [User] SET DeptId = 1, JoinDate = GETDATE();

