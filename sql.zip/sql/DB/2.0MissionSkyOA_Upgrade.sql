--Add Table

/****** Object:  Table [dbo].[Announcement]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Announcement](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Type] [int] NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Content] [nvarchar](max) NULL,
	[ApplyUserId] [int] NOT NULL,
	[EffectiveDays] [int] NULL,
	[CreateUserId] [int] NULL,
	[CreatedTime] [datetime2](7) NULL,
	[Status] [int] NULL,
	[AuditReason] [nvarchar](255) NULL,
	[RefAssetInventoryId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/****** Object:  Table [dbo].[Asset]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Asset](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[TypeId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[Status] [int] NULL,
 CONSTRAINT [PK_Asset_1] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[AssetAttribute]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AssetAttribute](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](255) NULL,
	[DataType] [int] NULL,
	[Sort] [int] NULL,
 CONSTRAINT [PK_AssetAttribute] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[AssetInfo]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AssetInfo](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[AssetId] [int] NOT NULL,
	[AttributeId] [int] NOT NULL,
	[AttributeValue] [nvarchar](255) NULL,
 CONSTRAINT [PK_Asset] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[AssetInventory]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AssetInventory](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](255) NOT NULL,
	[Description] [nvarchar](2000) NULL,
	[Status] [int] NULL,
	[CreatedTime] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_AssetInventory] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[AssetInventoryRecord]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AssetInventoryRecord](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[InventoryId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[AssetId] [int] NULL,
	[ScanCode] [nvarchar](50) NULL,
 CONSTRAINT [PK_AssetInventoryRecord] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[AssetTransaction]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AssetTransaction](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[AssetId] [int] NOT NULL,
	[BusinessType] [int] NULL,
	[OutUserId] [int] NOT NULL,
	[OutUserIsConfirm] [bit] NULL,
	[InUserId] [int] NOT NULL,
	[InUserIsConfirm] [bit] NULL,
	[Description] [nvarchar](255) NULL,
	[CreatedTime] [datetime2](7) NULL,
	[Status] [int] NULL,
 CONSTRAINT [PK_AssetUserChangeHitstory] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[AssetType]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AssetType](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Sort] [int] NULL,
 CONSTRAINT [PK_AssetType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[AssetTypeAttribute]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AssetTypeAttribute](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[TypeId] [int] NOT NULL,
	[AttributeId] [int] NOT NULL,
 CONSTRAINT [PK_AssetTypeAttribute] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[Attachment]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Attachment](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EntityType] [nvarchar](30) NOT NULL,
	[EntityId] [int] NOT NULL,
	[Name] [nvarchar](50) NULL,
	[Desc] [nvarchar](100) NULL,
	[Content] [varbinary](max) NULL,
	[CreatedTime] [datetime] NOT NULL DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[Book]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Book](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[ISBN] [nvarchar](30) NOT NULL,
	[Type] [nvarchar](30) NULL,
	[Desc] [ntext] NULL,
	[Author] [nvarchar](30) NULL,
	[Source] [int] NULL,
	[Donor] [int] NULL,
	[Status] [int] NULL,
	[Reader] [int] NULL,
	[CreatedDate] [datetime] NOT NULL DEFAULT (getdate()),
	[BarCode] [nvarchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/****** Object:  Table [dbo].[BookBorrow]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BookBorrow](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[BookId] [int] NOT NULL,
	[Status] [int] NULL,
	[BorrowDate] [datetime] NOT NULL,
	[ReturnDate] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[BookComment]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BookComment](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[BookId] [int] NOT NULL,
	[Comment] [ntext] NULL,
	[Rating] [int] NULL,
	[CreatedDate] [datetime] NOT NULL DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/****** Object:  Table [dbo].[DataDict]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DataDict](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Type] [nvarchar](30) NOT NULL,
	[Value] [nvarchar](30) NOT NULL,
	[Text] [nvarchar](30) NULL,
	[Parent] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[MeetingParticipant]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MeetingParticipant](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[MeetingCalendarId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[IsOptional] [char](5) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[Report]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Report](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Desc] [nvarchar](100) NULL,
	[CreatedTime] [datetime] NOT NULL DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[ReportConfig]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ReportConfig](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ReportId] [int] NOT NULL,
	[Config] [nvarchar](100) NOT NULL,
	[Value] [nvarchar](100) NOT NULL,
	[CreatedTime] [datetime] NOT NULL DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[ReportParameter]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ReportParameter](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ReportId] [int] NOT NULL,
	[Name] [nvarchar](30) NOT NULL,
	[Type] [nvarchar](20) NOT NULL,
	[Nullable] [bit] NULL,
	[CreatedTime] [datetime] NOT NULL DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[ScheduledTask]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ScheduledTask](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NULL,
	[Interval] [int] NOT NULL,
	[Unit] [int] NOT NULL,
	[Status] [int] NOT NULL,
	[TaskClass] [nvarchar](100) NOT NULL,
	[Desc] [nvarchar](100) NULL,
	[LastExecTime] [datetime] NULL,
	[CreatedTime] [datetime] NOT NULL DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[ScheduledTaskHistory]    Script Date: 2/2/2016 10:29:22 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ScheduledTaskHistory](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[TaskId] [int] NOT NULL,
	[Result] [bit] NOT NULL,
	[Desc] [ntext] NULL,
	[CreatedTime] [datetime] NOT NULL DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

--Add & Update Column

/****** Object:  Table [dbo].[Department]    Script Date: 2/2/2016 10:29:22 AM ******/
ALTER TABLE [dbo].[Department] ADD [CreateUserName] [nvarchar](30) NULL

ALTER TABLE [dbo].[Department] ADD [DepartmentHead] [int] NULL

ALTER TABLE [dbo].[Department] ADD [Status] [int] NULL

GO

/****** Object:  Table [dbo].[MeetingCalendar]    Script Date: 2/2/2016 10:29:22 AM ******/
ALTER TABLE [dbo].[MeetingCalendar] DROP COLUMN [Participants]

ALTER TABLE [dbo].[MeetingCalendar] DROP COLUMN [OptionalParticipants]

GO

/****** Object:  Table [dbo].[MeetingRoom]    Script Date: 2/2/2016 10:29:22 AM ******/
ALTER TABLE [dbo].[MeetingRoom] ALTER COLUMN [Status] [int] NULL

ALTER TABLE [dbo].[MeetingRoom] ADD [CreateUserName] [nvarchar](255) NULL

ALTER TABLE [dbo].[MeetingRoom] ADD [CreateDate] [datetime] NULL

GO

/****** Object:  Table [dbo].[Project]    Script Date: 2/2/2016 10:29:22 AM ******/
ALTER TABLE [dbo].[Project] ADD [ProjectNo] [nvarchar](100) NULL

ALTER TABLE [dbo].[Project] ADD [ProjectManager] [int] NULL

ALTER TABLE [dbo].[Project] ADD [ProjectBegin] [datetime] NULL

ALTER TABLE [dbo].[Project] ADD [ProjectEnd] [datetime] NULL

ALTER TABLE [dbo].[Project] ADD [CreateUserName] [nvarchar](255) NULL

ALTER TABLE [dbo].[Project] ADD [Status] [int] NULL

GO

/****** Object:  Table [dbo].[Role]    Script Date: 2/2/2016 10:29:22 AM ******/
ALTER TABLE [dbo].[Role] ADD [Abbreviation] [nvarchar](50) NULL

ALTER TABLE [dbo].[Role] ADD [IsInitRole] [int] NULL

ALTER TABLE [dbo].[Role] ADD [CreateUser] [nvarchar](255) NULL

ALTER TABLE [dbo].[Role] ADD [Status] [int] NULL

GO

--CONSTRAINT

ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [FK_Asset_AssetType] FOREIGN KEY([TypeId])
REFERENCES [dbo].[AssetType] ([Id])
GO

ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [FK_Asset_AssetType]
GO

ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [FK_Asset_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([Id])
GO

ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [FK_Asset_User]
GO

ALTER TABLE [dbo].[AssetInfo]  WITH CHECK ADD  CONSTRAINT [FK_AssetInfo_Asset1] FOREIGN KEY([AssetId])
REFERENCES [dbo].[Asset] ([Id])
GO

ALTER TABLE [dbo].[AssetInfo] CHECK CONSTRAINT [FK_AssetInfo_Asset1]
GO

ALTER TABLE [dbo].[AssetInfo]  WITH CHECK ADD  CONSTRAINT [FK_AssetInfo_AssetAttribute] FOREIGN KEY([AttributeId])
REFERENCES [dbo].[AssetAttribute] ([Id])
GO

ALTER TABLE [dbo].[AssetInfo] CHECK CONSTRAINT [FK_AssetInfo_AssetAttribute]
GO

ALTER TABLE [dbo].[AssetInventoryRecord]  WITH CHECK ADD  CONSTRAINT [FK_AssetInventoryRecord_AssetInventory] FOREIGN KEY([InventoryId])
REFERENCES [dbo].[AssetInventory] ([Id])
GO

ALTER TABLE [dbo].[AssetInventoryRecord] CHECK CONSTRAINT [FK_AssetInventoryRecord_AssetInventory]
GO

ALTER TABLE [dbo].[AssetTransaction]  WITH CHECK ADD  CONSTRAINT [FK_AssetTransaction_Asset] FOREIGN KEY([AssetId])
REFERENCES [dbo].[Asset] ([Id])
GO

ALTER TABLE [dbo].[AssetTransaction] CHECK CONSTRAINT [FK_AssetTransaction_Asset]
GO

ALTER TABLE [dbo].[AssetTypeAttribute]  WITH CHECK ADD  CONSTRAINT [FK_AssetTypeAttribute_AssetAttribute] FOREIGN KEY([AttributeId])
REFERENCES [dbo].[AssetAttribute] ([Id])
GO

ALTER TABLE [dbo].[AssetTypeAttribute] CHECK CONSTRAINT [FK_AssetTypeAttribute_AssetAttribute]
GO

ALTER TABLE [dbo].[AssetTypeAttribute]  WITH CHECK ADD  CONSTRAINT [FK_AssetTypeAttribute_AssetType] FOREIGN KEY([TypeId])
REFERENCES [dbo].[AssetType] ([Id])
GO

ALTER TABLE [dbo].[AssetTypeAttribute] CHECK CONSTRAINT [FK_AssetTypeAttribute_AssetType]
GO

ALTER TABLE [dbo].[MeetingCalendar]  WITH CHECK ADD FOREIGN KEY([MeetingRoomId])
REFERENCES [dbo].[MeetingRoom] ([Id])
GO

ALTER TABLE [dbo].[MeetingParticipant]  WITH CHECK ADD FOREIGN KEY([MeetingCalendarId])
REFERENCES [dbo].[MeetingCalendar] ([Id])
GO

ALTER TABLE [dbo].[MeetingParticipant]  WITH CHECK ADD FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([Id])
GO

ALTER TABLE [dbo].[ReportConfig]  WITH CHECK ADD  CONSTRAINT [FK_Report_Config] FOREIGN KEY([ReportId])
REFERENCES [dbo].[Report] ([Id])
GO

ALTER TABLE [dbo].[ReportConfig] CHECK CONSTRAINT [FK_Report_Config]
GO

ALTER TABLE [dbo].[ReportParameter]  WITH CHECK ADD  CONSTRAINT [FK_Report_Parameter] FOREIGN KEY([ReportId])
REFERENCES [dbo].[Report] ([Id])
GO

ALTER TABLE [dbo].[ReportParameter] CHECK CONSTRAINT [FK_Report_Parameter]
GO

ALTER TABLE [dbo].[ScheduledTaskHistory]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledTask_History] FOREIGN KEY([TaskId])
REFERENCES [dbo].[ScheduledTask] ([Id])
GO

ALTER TABLE [dbo].[ScheduledTaskHistory] CHECK CONSTRAINT [FK_ScheduledTask_History]
GO

