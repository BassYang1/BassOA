﻿SELECT EnglishName, JoinDate, YEAR(JoinDate) [入职年份], MONTH(JoinDate) [入职月份],
       DATEDIFF(MONTH,JoinDate,'2016-01-01') [在职月份数],
	   case when 2016 - YEAR(JoinDate) = 1 and MONTH(JoinDate) <= 7 then 5.5
		     when 2016 - YEAR(JoinDate) = 1 and MONTH(JoinDate) > 7 then 5
			 when 2016 - YEAR(JoinDate) > 1 and MONTH(JoinDate) <= 7 then 5 + 2016 - YEAR(JoinDate)
			 when 2016 - YEAR(JoinDate) > 1 and MONTH(JoinDate) > 7 then 5 + 2016 - YEAR(JoinDate) - 1
			 end [基础年假天数],
	   case when 2016 - YEAR(JoinDate) = 1 and MONTH(JoinDate) <= 7 then (5*7.5+4)
		     when 2016 - YEAR(JoinDate) = 1 and MONTH(JoinDate) > 7 then (5*7.5)
			 when 2016 - YEAR(JoinDate) > 1 and MONTH(JoinDate) <= 7 then (5 + 2016 - YEAR(JoinDate))*7.5
			 when 2016 - YEAR(JoinDate) > 1 and MONTH(JoinDate) > 7 then (5 + 2016 - YEAR(JoinDate) - 1)*7.5
			 end [基础年假小时数]
FROM [User]
WHERE EnglishName NOT IN ('Feng Xuan', 'Waikei Tam', 'Amy Bao', 'Likko Zhang', 'Jane Hu', 'Jessie Zhang', 'Arthur Luo', 'Eric.Liu', 'Hardy Xu', 'John Huang', 'Gordon Chen','Johnson Wang')
union all
SELECT EnglishName, JoinDate, YEAR(JoinDate) [入职年份], MONTH(JoinDate) [入职月份],
       DATEDIFF(MONTH,JoinDate,'2016-01-01') [在职月份数],
	   case when 2016 - YEAR(JoinDate) = 1 and MONTH(JoinDate) <= 7 then 10.5
		     when 2016 - YEAR(JoinDate) = 1 and MONTH(JoinDate) > 7 then 10
			 when 2016 - YEAR(JoinDate) > 1 and MONTH(JoinDate) <= 7 then 10 + 2016 - YEAR(JoinDate)
			 when 2016 - YEAR(JoinDate) > 1 and MONTH(JoinDate) > 7 then 10 + 2016 - YEAR(JoinDate) - 1
			 end [基础年假天数],
	    case when 2016 - YEAR(JoinDate) = 1 and MONTH(JoinDate) <= 7 then (10*7.5+4)
		     when 2016 - YEAR(JoinDate) = 1 and MONTH(JoinDate) > 7 then (10*7.5)
			 when 2016 - YEAR(JoinDate) > 1 and MONTH(JoinDate) <= 7 then (10 + 2016 - YEAR(JoinDate))*7.5
			 when 2016 - YEAR(JoinDate) > 1 and MONTH(JoinDate) > 7 then (10 + 2016 - YEAR(JoinDate) - 1)*7.5
			 end [基础年假小时数]
FROM [User]
WHERE EnglishName IN ('Feng Xuan', 'Waikei Tam', 'Amy Bao', 'Likko Zhang', 'Jane Hu', 'Jessie Zhang', 'Arthur Luo', 'Eric.Liu', 'Hardy Xu', 'John Huang', 'Gordon Chen','Johnson Wang')

UPDATE [AttendanceSummary]
SET BaseValue = (SELECT TOP 1 case when 2016 - YEAR(JoinDate) = 1 and MONTH(JoinDate) <= 7 then (5*7.5+4)
		     when 2016 - YEAR(JoinDate) = 1 and MONTH(JoinDate) > 7 then (5*7.5)
			 when 2016 - YEAR(JoinDate) > 1 and MONTH(JoinDate) <= 7 then (5 + 2016 - YEAR(JoinDate))*7.5
			 when 2016 - YEAR(JoinDate) > 1 and MONTH(JoinDate) > 7 then (5 + 2016 - YEAR(JoinDate) - 1)*7.5
			 end
		FROM [User]
		WHERE Id = UserId)
WHERE [TYPE]=1
AND UserId IN (SELECT id FROM [USER] WHERE EnglishName NOT IN ('Feng Xuan', 'Waikei Tam', 'Amy Bao', 'Likko Zhang', 'Jane Hu', 'Jessie Zhang', 'Arthur Luo', 'Eric.Liu', 'Hardy Xu', 'John Huang', 'Gordon Chen'))


UPDATE [AttendanceSummary]
SET BaseValue = (SELECT TOP 1 case when 2016 - YEAR(JoinDate) = 1 and MONTH(JoinDate) <= 7 then (10*7.5+4)
		     when 2016 - YEAR(JoinDate) = 1 and MONTH(JoinDate) > 7 then (10*7.5)
			 when 2016 - YEAR(JoinDate) > 1 and MONTH(JoinDate) <= 7 then (10 + 2016 - YEAR(JoinDate))*7.5
			 when 2016 - YEAR(JoinDate) > 1 and MONTH(JoinDate) > 7 then (10 + 2016 - YEAR(JoinDate) - 1)*7.5
			 end
		FROM [User]
		WHERE Id = UserId)
WHERE [TYPE]=1
AND UserId IN (SELECT id FROM [USER] WHERE EnglishName IN ('Feng Xuan', 'Waikei Tam', 'Amy Bao', 'Likko Zhang', 'Jane Hu', 'Jessie Zhang', 'Arthur Luo', 'Eric.Liu', 'Hardy Xu', 'John Huang', 'Gordon Chen','Johnson Wang'))

UPDATE [AttendanceSummary]
SET RemainValue = LastValue + BaseValue
WHERE [TYPE] = 1
